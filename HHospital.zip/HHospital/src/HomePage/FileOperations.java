package HomePage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class FileOperations {
	FileOperations(){}
	
	//sendValue ==> -2: Member could not found. / -1: Continue reading the files.
	//i ==> 0: Admin (member found). / 1: Doctor (member found). / 2: Nurse (member found). / 3: secretary (member found).
	public int checkMember(String checkName, String checkSurname, String checkPassword) {
		int sendValue = -1;
		String fileName = null;
		
		for(int i = 0; i < 4; i++) {
			if(i == 0)
				fileName = "adminFile.txt";
			else if(i == 1)
				fileName = "doctorFile.txt";
			else if(i == 2)
				fileName = "nurseFile.txt";
			else if(i == 3)
				fileName = "secretaryFile.txt";
			
			sendValue = readFile(checkName, checkSurname, checkPassword, fileName, i);
			
			//If member found. Send info to related profession GUI.
			if(sendValue >= 0) {
				return i;
			}
			if(sendValue == -1 && i == 3)
				return -2;
		}
		
		return -1;
	}
	private int readFile(String checkName, String checkSurname, String checkPassword, String fileName, int getLoop) {
		int sendValue = -1;
		String tempName, tempSurname, tempPassword, tempBirthDate, tempGender;
		
		long tempPhoneNumber = 0, tempIN = 0;
		String tempSecurityAns1 = null;
		
		File file = new File(fileName);
		
		if(!file.exists())
			return -1;
		else {
			try {
				Scanner scan = new Scanner(file);
				
				//File check point!
				while(scan.hasNextLine()) {
					tempIN = scan.nextLong();
					
					scan.nextLine();
					tempName = scan.nextLine();
					
					tempSurname = scan.next();
					tempPassword = scan.next();
					
					tempBirthDate = scan.next();
					tempGender = scan.next();
					tempPhoneNumber = scan.nextLong();
					
					scan.nextLine();
					tempSecurityAns1 = scan.nextLine();
					scan.nextLine();
					
					/*System.out.println("IN: " + tempIN);
					System.out.println("Isim: " + tempName);
					System.out.println("Soyisim: " + tempSurname);
					System.out.println("Sifre: " + tempPassword);
					System.out.println("Birth Date: " + tempBirthDate);
					System.out.println("Gender: " + tempGender);
					System.out.println("Phone Number: " + tempPhoneNumber);
					System.out.println("Security Ans1: " + tempSecurityAns1 + "\n\n");*/
					
					if(checkName.equals(tempName) && checkSurname.equals(tempSurname) && checkPassword.equals(tempPassword)) {
						sendValue = (int) tempIN;
						break;
					}
				}
				
				scan.close();
				return sendValue;
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		return -1;
	}
	
	public int forgotPasswordCheckMember(String checkIN, String checkName, String checkSurname, String setPassword,
			String getProfession, String checkAns1) {
		
		int sendValue = 0;
		String fileName = null, tempName = null, tempSurname = null, tempPassword = null,  tempIN = null;
		String tempBirthDate = null, tempGender = null;
		
		long tempPhoneNumber = 0;
		String tempSecurityAns = null;
		
		if(getProfession.equals("Doctor"))
			fileName = "doctorFile.txt";
		else if(getProfession.equals("Nurse"))
			fileName = "nurseFile.txt";
		else if(getProfession.equals("Secretary"))
			fileName = "secretaryFile.txt";
		
		//File check section.
		File file = new File(fileName);
		File tempFile = new File("temp.txt");
		
		try {
			Scanner scan = new Scanner(file);
			BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile, true));
			
			while(scan.hasNextLine()) {
				tempIN = scan.next();
				
				scan.nextLine();
				tempName = scan.nextLine();
				
				tempSurname = scan.next();
				tempPassword = scan.next();
				tempBirthDate = scan.next();
				tempGender = scan.next();

				tempPhoneNumber = scan.nextLong();
				scan.nextLine();
				
				tempSecurityAns = scan.nextLine();
				scan.nextLine();

				bw.write(tempIN + "\n" + tempName + "\n" + tempSurname + "\n");
				if(checkIN.equals(tempIN) && checkName.equals(tempName) && checkSurname.equals(tempSurname)&&
						checkAns1.equals(tempSecurityAns)) {
					
					bw.write(setPassword + "\n");
					sendValue = 1;
				}
				else
					bw.write(tempPassword + "\n");
				
				bw.write(tempBirthDate + "\n" + tempGender + "\n" + tempPhoneNumber + "\n" + tempSecurityAns + "\n\n");
			}
			
			scan.close();
			bw.close();
			file.delete();
			tempFile.renameTo(file);
			
			return sendValue;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
}