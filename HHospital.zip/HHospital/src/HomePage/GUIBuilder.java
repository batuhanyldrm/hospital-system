package HomePage;

import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GUIBuilder {
	public GUIBuilder(){}
	public void initiate() {}
	
	public GUIBuilder(Builder builder, JPanel panel, JComponent component, GridBagConstraints gbc){
		if(builder.setAlignment == 0)
			gbc.fill = GridBagConstraints.HORIZONTAL;
		else 
			gbc.fill = GridBagConstraints.VERTICAL;
			
		
		gbc.gridx = builder.gridX;
		gbc.gridy = builder.gridY;
		
		gbc.insets = new Insets(builder.top, builder.left, builder.bottom, builder.right);
		gbc.ipadx = builder.iPadX;
		gbc.ipady = builder.iPadY;
		
		if(builder.gridHeight > 0) {
			gbc.gridheight = builder.gridHeight;
		}
		else if(builder.gridWidth > 0){
			gbc.gridwidth = builder.gridWidth;
		}
		
		panel.add(component, gbc);
	}
	
	public static class Builder{
		private int gridX = 0, gridY = 0, top = 0, left = 0, bottom = 0, right = 0, iPadX = 0, iPadY = 0, setAlignment = 0;
		private int gridWidth = 0, gridHeight = 0;
		public Builder(){}
		
		public Builder gridX(int gridX) {
			this.gridX = gridX;
			return this;
		}
		public Builder gridY(int gridY) {
			this.gridY = gridY;
			return this;
		}
		public Builder top(int top) {
			this.top = top;
			return this;
		}
		public Builder left(int left) {
			this.left = left;
			return this;
		}
		public Builder bottom(int bottom) {
			this.bottom = bottom;
			return this;
		}
		public Builder right(int right) {
			this.right = right;
			return this;
		}
		public Builder iPadX(int iPadX) {
			this.iPadX = iPadX;
			return this;
		}
		public Builder iPadY(int iPadY) {
			this.iPadY = iPadY;
			return this;
		}
		public Builder setAlignment(int setAlignment) {
			if(setAlignment < 0 || setAlignment > 1) {
				System.out.println("Set alignment must between 0 and 1.");
				return null;
			}
				
			this.setAlignment = setAlignment;
			return this;
		}
		public Builder gridWidth(int gridWidth) {
			this.gridWidth = gridWidth;
			return this;
		}
		public Builder gridHeight(int gridHeight) {
			this.gridHeight = gridHeight;
			return this;
		}
		public GUIBuilder builder(JPanel panel, JComponent component, GridBagConstraints gbc) {
			return new GUIBuilder(this, panel, component, gbc);
		}
	}
	
	public void changeIcon(JFrame frame) {
		Image icon = Toolkit.getDefaultToolkit().getImage("HHospitalLogo.jpg");
		frame.setIconImage(icon);
	}
	public void addImage(JPanel panel) {
		try {
			BufferedImage image = ImageIO.read(new File("HHospitalLogo2.png"));
			JLabel picLabel = new JLabel(new ImageIcon(image));
			panel.add(picLabel);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}