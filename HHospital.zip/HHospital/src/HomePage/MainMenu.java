package HomePage;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Nurse.NurseGUI;
import OOPDoctor.*;
import Secretary.*;
import Manager.*;

public class MainMenu extends GUIBuilder implements ActionListener{
	public JFrame frame;
	private JPanel panel, logoPanel, HLogo;
	private JButton signInButton, forgotPassword;
	private JTextField nameField, surnameField;
	private JPasswordField passwordField;
	
	public MainMenu() {
		initiate();
	}
	public static void main(String[] args) {
		new MainMenu();
	}
	public void initiate() {
		frame = new JFrame("Welcome to HHospital Main Menu");
		frame.setBounds(300, 150, 750, 500);
		frame.setLayout(null);
		
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		
		changeIcon(frame);
		//addImage(panel);
		logoPanelComponent();
		setHLogo();
		panelContent();
	}
	private void setHLogo() {
		HLogo = new JPanel(new GridBagLayout());
		frame.add(HLogo);
		HLogo.setBounds(220, 73, 77, 80);
		HLogo.setBackground(Color.LIGHT_GRAY);
		
		GridBagConstraints hLogo = new GridBagConstraints();
		JLabel hLabel = new JLabel("H");
		hLabel.setFont(new Font("Calibri", Font.BOLD, 105));

		new GUIBuilder.Builder().gridX(0).gridY(0).left(10).builder(HLogo, hLabel, hLogo);
		frame.setVisible(true);
	}
	private void logoPanelComponent() {
		logoPanel = new JPanel(new GridBagLayout());
		frame.add(logoPanel);
		logoPanel.setBounds(220, 60, 250, 100);
		logoPanel.setBackground(Color.LIGHT_GRAY);
		
		GridBagConstraints gbcLogo = new GridBagConstraints();
		
		//JLabel hLabel = new JLabel("H");
		JLabel hospital = new JLabel("Hospital");
		JLabel slogan = new JLabel("ealth for everyone");

		hospital.setFont(new Font("Calibri", Font.BOLD, 40));
		slogan.setFont(new Font("Calibri", Font.ITALIC, 20));
		
		new GUIBuilder.Builder().gridX(1).gridY(0).left(50).builder(logoPanel, hospital, gbcLogo);
		new GUIBuilder.Builder().gridX(1).gridY(1).left(50).builder(logoPanel, slogan, gbcLogo);
		
		frame.setVisible(true);
	}
	private void panelContent() {
		panel = new JPanel(new GridBagLayout());
		frame.add(panel);
		panel.setBounds(170, 200, 350, 230);
		panel.setBackground(Color.LIGHT_GRAY);
		
		GridBagConstraints gbc = new GridBagConstraints();
		Font font = new Font("Calibri", Font.BOLD, 20);
		
		JLabel name = new JLabel("Name: ");
		JLabel surname = new JLabel("Surname: ");
		JLabel password = new JLabel("Password: ");
		
		name.setFont(font);
		surname.setFont(font);
		password.setFont(font);
		
		nameField = new JTextField(15);
		surnameField = new JTextField(15);
		passwordField = new JPasswordField(15);
		
		signInButton = new JButton("Sign In");
		signInButton.setBorderPainted(false);
		signInButton.addActionListener(this);
		
		forgotPassword = new JButton();
		forgotPassword.setText("Forgot your password?");
		forgotPassword.setBorderPainted(false);
		forgotPassword.setOpaque(true);
		forgotPassword.setContentAreaFilled(false);
		forgotPassword.addActionListener(this);
		
		new GUIBuilder.Builder().gridX(0).gridY(0).top(20).right(10).builder(panel, name, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(0).top(20).iPadY(7).builder(panel, nameField, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(1).right(10).top(10).builder(panel, surname, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(1).top(10).iPadY(7).builder(panel, surnameField, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(2).right(10).top(10).builder(panel, password, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(2).top(10).iPadY(7).builder(panel, passwordField, gbc);

		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.insets = new Insets(20, 0, 0, 0);
		panel.add(signInButton, gbc);
		
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.insets = new Insets(5, 0, 0, 0);
		panel.add(forgotPassword, gbc);
		
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e){  
        if(e.getSource() == signInButton) {
        	int getResult = 0;
        	
        	String getName = nameField.getText().trim();
        	String getSurname = surnameField.getText().trim();
        	String getPassword = new String(passwordField.getPassword());
        	
        	FileOperations fo = new FileOperations();
        	getResult = fo.checkMember(getName, getSurname, getPassword);
        	
        	if(getResult == -2) {
        		JOptionPane.showMessageDialog(frame, "Wrong name, surname or password. Please \ncheck your information again.");
        	}
        	else if(getResult == 0) {
				//Call the admin page.
				frame.setVisible(false);
				new Main();
        	}
        	else if(getResult == 1) {
        		//Call the doctor page.
				frame.setVisible(false);
				new MainPage().setName(getName, getSurname);
        	}
        	else if(getResult == 2) {
        		frame.setVisible(false);
        		new NurseGUI(getName, getSurname, getPassword);
        	}
        	else if(getResult == 3) {
				//Call the secretary page.
				frame.setVisible(false);
				new GuiMainPage();
        	}	
        }
        else if(e.getSource() == forgotPassword) {
        	new ForgotPassword();
        }
	}
}