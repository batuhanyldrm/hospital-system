package HomePage;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ForgotPassword extends GUIBuilder implements ActionListener{
	private JFrame frame;
	private JPanel titlePanel, panel, panel2;
	private JLabel name, surname, info, password, repeatPassword, iNumber, profession;
	private JPasswordField passwordField, passwordField2;
	private JTextField nameField, surnameField, ans1, iNumberField;
	private JButton okButton;
	private JComboBox firstQuestion, secondQuestion, professionBox;
	
	ForgotPassword(){
		initiate();
	}
	
	public void initiate() {
		frame = new JFrame("Forgot Your Password?");
		frame.setLayout(null);
		frame.setBounds(400, 250, 400, 440);
		
		frame.setVisible(true);
		frame.setResizable(false);
		changeIcon(frame);
		
		setTitlePanel();
		panelContent();
		panelContent2();
	}
	private void setTitlePanel() {
		titlePanel = new JPanel();
		frame.add(titlePanel);
		titlePanel.setBounds(0, 0, 400, 50);
		titlePanel.setBackground(Color.LIGHT_GRAY);
		
		JLabel titleLabel = new JLabel("Please Fill the Blanks");
		titleLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		titlePanel.add(titleLabel);
		
		frame.setVisible(true);
	}
	private void panelContent() {
		panel = new JPanel(new GridBagLayout());
		frame.add(panel);
		panel.setBounds(0, 50, 400, 200);
		panel.setBackground(Color.LIGHT_GRAY);
		
		String[] setProfession = new String[3];
		setProfession[0] = "Doctor";
		setProfession[1] = "Nurse";
		setProfession[2] = "Secretary";
		
		GridBagConstraints gbc = new GridBagConstraints();
		Font font = new Font("Calibri", Font.BOLD, 18);
		
		iNumber = new JLabel("Identification Number: ");
		name = new JLabel("Name: ");
		surname = new JLabel("Surname: ");
		password = new JLabel("New Password: ");
		repeatPassword = new JLabel("Repeat Password: ");
		profession = new JLabel("Your Profession: ");
		
		nameField = new JTextField(15);
		surnameField = new JTextField(15);
		
		passwordField = new JPasswordField(15);
		passwordField2 = new JPasswordField(15);
		iNumberField = new JTextField(15);
		
		professionBox = new JComboBox(setProfession);
		professionBox.setSelectedIndex(0);
		
		name.setFont(font);
		surname.setFont(font);
		password.setFont(font);
		repeatPassword.setFont(font);
		iNumber.setFont(font);
		profession.setFont(font);
		
		new GUIBuilder.Builder().gridX(0).gridY(0).right(10).builder(panel, iNumber, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(0).builder(panel, iNumberField, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(1).top(10).builder(panel, name, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(1).top(10).builder(panel, nameField, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(2).top(10).builder(panel, surname, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(2).top(10).builder(panel, surnameField, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(3).top(10).builder(panel, password, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(3).top(10).builder(panel, passwordField, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(4).top(10).builder(panel, repeatPassword, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(4).top(10).builder(panel, passwordField2, gbc);
		new GUIBuilder.Builder().gridX(0).gridY(5).top(10).builder(panel, profession, gbc);
		new GUIBuilder.Builder().gridX(1).gridY(5).top(10).builder(panel, professionBox, gbc);
		
		frame.setVisible(true);
	}
	private void panelContent2() {
		panel2 = new JPanel(new GridBagLayout());
		frame.add(panel2);
		panel2.setBounds(0, 250, 400, 160);
		panel2.setBackground(Color.LIGHT_GRAY);
		
		GridBagConstraints gbc2 = new GridBagConstraints();
		
		String[] addQuestions = new String[5];
		addQuestions[0] = "What was your childhood nickname?";
		addQuestions[1] = "What is the name of your favorite childhood friend?";
		addQuestions[2] = "What was your dream job as a child?";
		addQuestions[3] = "Who was your childhood hero?";
		addQuestions[4] = "In what city and country do you want to retire?";
		
		info = new JLabel("(Please answer the security questions.)");
		ans1 = new JTextField(15);
		
		firstQuestion = new JComboBox(addQuestions);
		firstQuestion.setSelectedIndex(0);
		
		secondQuestion = new JComboBox(addQuestions);
		secondQuestion.setSelectedIndex(1);
		
		okButton = new JButton("OK");
		okButton.addActionListener(this);
		
		new GUIBuilder.Builder().gridX(0).gridY(0).builder(panel2, info, gbc2);		
		new GUIBuilder.Builder().gridX(0).gridY(1).top(10).builder(panel2, firstQuestion, gbc2);
		new GUIBuilder.Builder().gridX(0).gridY(2).top(5).builder(panel2, ans1, gbc2);

		gbc2.fill = GridBagConstraints.HORIZONTAL;
		gbc2.gridx = 0;
		gbc2.gridy = 5;
		gbc2.insets = new Insets(15, 0, 0, 0);
		
		panel2.add(okButton, gbc2);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == okButton) {
			int getResult = 0;
			
			String getIN = iNumberField.getText().trim();
			String getNameField = nameField.getText().trim();
			String getSurnameField = surnameField.getText().trim();
			String getPassword1 = new String(passwordField.getPassword());
			String getPassword2 = new String(passwordField2.getPassword());
			String getProfession = (String) professionBox.getSelectedItem();
			
			String getAns1 = ans1.getText().trim();
			
			if(getPassword1.equals(getPassword2)) {
				FileOperations fo = new FileOperations();
				getResult = fo.forgotPasswordCheckMember(getIN, getNameField, getSurnameField, getPassword1, getProfession, getAns1);
			}
			else
				JOptionPane.showMessageDialog(frame, "Password fields does not match. Please check it again.");
			
			
			if(getResult == 0)
				JOptionPane.showMessageDialog(frame, "Member could not found. Please check your information again.");
			else
				JOptionPane.showMessageDialog(frame, "Your password changed successfully.");
		}
	}
}