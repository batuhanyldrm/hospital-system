package Nurse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

//Director class.
public class TestCommandFile {
    Command command;

    public void setCommand(Command command){
        this.command = command;
    }

    public void executeOperation(){
        command.execute();
    }
    public String executeOperation(String IN){
        return command.execute(IN);
    }
    public String[][] executeOperation(int rows, int columns){
        return command.execute(rows, columns);
    }
    public int executeOperation(String IN, String result){
        return command.execute(IN, result);
    }
}

//Command class.
class Command {
    public void execute(){}
    public String execute(String IN){
        return null;
    }
    public String[][] execute(int rows, int data){
        return null;
    }
    public int execute(String IN, String result){
        return 0;
    }
}

class SeeWishTest extends Command{
    WishTestOperations wto;
    
    public SeeWishTest(WishTestOperations wto){
        this.wto = wto;
    }

    public String execute(String IN){
        return wto.displayTestResult(IN);
    }
}

class FillTable extends Command{
    WishTestOperations wto;

    public FillTable(WishTestOperations wto){
        this.wto = wto;
    }

    public String[][] execute(int rows, int columns){
        return wto.returnTableValues(rows, columns);
    }
}

class Result extends Command{
    WishTestOperations wto;

    public Result(WishTestOperations wto){
        this.wto = wto;
    }

    public int execute(String IN, String result){
        return wto.setResult(IN, result);
    }
}

//Operation class.
class WishTestOperations {
    String returnResult = null;
    String tempIN, tempName, tempSurname, tempTestName, tempTestResult;

    public String displayTestResult(String IN){
        File file = new File("resultWishTest.txt");

        if(!file.exists()){
            //
        }
        else{
            try{
                Scanner scan = new Scanner(file);

                while(scan.hasNextLine()){
                    tempIN = scan.next();
                    scan.nextLine();

                    tempName = scan.nextLine();
                    tempSurname = scan.next();
                    scan.nextLine();

                    tempTestName = scan.nextLine();
                    tempTestResult = scan.nextLine();
                    scan.nextLine();

                    if(IN.equals(tempIN)){
                        returnResult = IN + "@" + tempName + "@" + tempSurname + "@" + tempTestName + "@" + tempTestResult;
                        break;
                    }
                }
                scan.close();
                return returnResult;
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        
        return null;
    }

    public String[][] returnTableValues(int rows, int columns){
        int i = 0;
        String[][] data = new String[rows][columns];
        File file = new File("wishTest.txt");

        try{
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                //Identification number.
                data[i][0] = scan.next();

                //Name.
                scan.nextLine();
                data[i][1] = scan.nextLine();

                //Surname.
                data[i][2] = scan.next();

                //Wish test.
                scan.nextLine();
                data[i][3] = scan.nextLine();
                scan.nextLine();

                i++;
            }
            scan.close();
            return data;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    //Return values -
    //-1: file not found,
    // 0: patient not found,
    // 1: operation succeeded.
    public int setResult(String IN, String result){
        int sendReturn = 0;

        try{
            File file = new File("wishTest.txt");
            File resultFile = new File("resultWishTest.txt");

            if(!file.exists())
                return -1;

            Scanner scan = new Scanner(file);
            BufferedWriter bw = new BufferedWriter(new FileWriter(resultFile, true));

            while(scan.hasNextLine()){
                tempIN = scan.next();
                scan.nextLine();

                tempName = scan.nextLine();
                tempSurname = scan.next();

                scan.nextLine();
                tempTestName = scan.nextLine();
                scan.nextLine();

                if(IN.equals(tempIN)){
                    sendReturn = 1;
                    break;
                }
            }

            if(sendReturn == 1){
                bw.write(IN + "\n" + tempName + "\n" + tempSurname + "\n" + tempTestName + "\n" + result + "\n\n");

                bw.close();
                scan.close();
                cleanWTFile(IN);
            }

            return sendReturn;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return sendReturn;
    }

    public void cleanWTFile(String IN){
        try{
            File file = new File("wishTest.txt");
            File tempFile = new File("tempWishTestFile.txt");

            if(!file.exists())
                return;

            Scanner scan = new Scanner(file);
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile, true));

            while(scan.hasNextLine()){
                tempIN = scan.next();
                scan.nextLine();

                tempName = scan.nextLine();
                tempSurname = scan.next();

                scan.nextLine();
                tempTestName = scan.nextLine();
                scan.nextLine();

                if(!IN.equals(tempIN)){
                    bw.write(tempIN + "\n" + tempName + "\n" + tempSurname + "\n" + tempTestName + "\n\n");
                }
            }

            bw.close();
            scan.close();
            file.delete();
            tempFile.renameTo(file);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}