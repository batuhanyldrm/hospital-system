package Nurse;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.TableColumn;

import HomePage.GUIBuilder;

public class AddTestResult {
    private JFrame frame;
    private JPanel panel;
    private JTextField INField, resultField;
    private JButton okButton;
    private JScrollPane sPane;

    public AddTestResult(JFrame frame){
        this.frame = frame;
        new GUIBuilder().changeIcon(frame);
        initialize();
    }

    protected AddTestResult getInstance(){
        return this;
    }

    protected void hidePanel(){
        sPane.setVisible(false);
        panel.setVisible(false);
    }

    private void initialize(){
        frame.setVisible(true);
        setJScrollPane();
        setPanel();
    }

    private void setJScrollPane(){
        String[] column = {"Identification Number", "Name", "Surname", "Wish Test"};
        String[][] data;

        TestCommandFile tcf = new TestCommandFile();
        WishTestOperations wto = new WishTestOperations();
        tcf.setCommand(new FillTable(wto));
        data = tcf.executeOperation(10, 4);

        JTable jt = new JTable(data, column){
            private static final long serialVersionUID = 1L;

            public boolean isCellEditable(int data, int column) {
                return false;
           }
        };

        TableColumn col = jt.getColumnModel().getColumn(0);
        col.setMinWidth(120);
        col.setMaxWidth(120);
        col.setPreferredWidth(120);

        col = jt.getColumnModel().getColumn(1);
        col.setMinWidth(120);
        col.setMaxWidth(120);
        col.setPreferredWidth(120);

        col = jt.getColumnModel().getColumn(2);
        col.setMinWidth(100);
        col.setMaxWidth(100);
        col.setPreferredWidth(100);

        sPane = new JScrollPane(jt);
        sPane.setBounds(215, 5, 500, 200);
        frame.add(sPane);
        frame.setVisible(true);
    }

    private void setPanel(){
        panel = new JPanel(new GridBagLayout());
        frame.add(panel);
        panel.setBounds(215, 205, 500, 230);
        panel.setBackground(Color.LIGHT_GRAY);

        Font font = new Font("Calibri", Font.BOLD, 20);
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel iNLabel = new JLabel("Identification Number: ");
        JLabel resultLabel = new JLabel("Enter the Test Result: ");

        iNLabel.setFont(font);
        resultLabel.setFont(font);

        INField = new JTextField(20);
        resultField = new JTextField(20);

        okButton = new JButton("OK");
        okButton.addActionListener(new MouseAction());

        new InfoBuilder.Builder().gridX(0).gridY(0).right(10).builder(panel, iNLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).builder(panel, INField, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(10).right(10).builder(panel, resultLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(1).top(10).builder(panel, resultField, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(2).top(10).builder(panel, okButton, gbc);

        frame.setVisible(true);
    }

    private class MouseAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            int getResult = 0;
            String getINField = INField.getText().trim();
            String getResultField = resultField.getText().trim();

            if(getINField.equals("") || getResultField.equals(""))
                JOptionPane.showMessageDialog(frame, "Please fill the areas.");
            else{
                TestCommandFile tcomf = new TestCommandFile();
                WishTestOperations wtesto = new WishTestOperations();
                tcomf.setCommand(new Result(wtesto));
                getResult = tcomf.executeOperation(getINField, getResultField);

                if(getResult == 1){
                    JOptionPane.showMessageDialog(frame, "Test result successfully added.");
                    
                    sPane.setVisible(false);
                    setJScrollPane();
                }
                else if(getResult == 0)
                    JOptionPane.showMessageDialog(frame, "Patient not found!");
                else if(getResult == -1)
                    JOptionPane.showMessageDialog(frame, "Error Occured: File not found.");
            }            
        }
    }
}