package Nurse;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import HomePage.GUIBuilder;

public class NurseGUI {
	private String name = null, surname = null, password = null;
	private AnamnesisGUI anamnesisGUIInstance = null;
	private ViewTest viewTestInstance = null;
	private AddTestResult addTestResultInstance = null;
	private ShowAnamnesisInfo sAnamnesisInstance = null;
	
	private JFrame frame = new NurseSingleton().getFrame();
	private JPanel panel;
	private JButton anamnesis, showAnamnesisInfo, viewTest, addTResult;
	
	public NurseGUI(String name, String surname, String password){
		this.name = name;
		this.surname = surname;
		this.password = password;
		
		initialize();
	}
	public NurseGUI() {
		initialize();
	}
	public NurseGUI(String[] getDivide){
		this.name = getDivide[0];
		this.surname = getDivide[1];
		this.password = getDivide[2];

		/*System.out.println(this.name);
		System.out.println(this.surname);
		System.out.println(this.password);*/
	}

	public static void main(String[] args) {
		new NurseGUI();
	}
	public void initialize() {
		frame.setBounds(300, 150, 750, 500);
		frame.setTitle("Nurse Page");
		frame.setLayout(null);
		frame.setBackground(Color.LIGHT_GRAY);
		
		new GUIBuilder().changeIcon(frame);
		
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		
		setMenuBar();
		configurePanel();
	}
	private void setMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu options = new JMenu("Options");
		
		JMenuItem exit = new JMenuItem("Exit");
		exit.setActionCommand("exit");
		
		JMenuItem updateInfo = new JMenuItem("Update Information");
		updateInfo.setActionCommand("updateInformation");
		
		JMenuItem showInfo = new JMenuItem("Show Information");
		showInfo.setActionCommand("showInformation");

		MenuItemListener menuItemListener = new MenuItemListener();
		exit.addActionListener(menuItemListener);
		updateInfo.addActionListener(menuItemListener);
		showInfo.addActionListener(menuItemListener);
		
		options.add(exit);
		options.addSeparator();
		options.add(updateInfo);
		options.add(showInfo);
		
		menuBar.add(options);
		frame.setJMenuBar(menuBar);
		frame.setVisible(true);
	}
	private void configurePanel() {
		panel = new JPanel();
		frame.add(panel);
		panel.setBounds(5, 5, 200, 250);
		
		Font font = new Font("Calibri", Font.BOLD, 20);
		GridLayout gridLayout = new GridLayout(4, 0);
		gridLayout.setVgap(5);
		
		CPanelButtons performAction = new CPanelButtons();
		
		anamnesis = new JButton("Anamnesis");
		anamnesis.setFont(font);
		//anamnesis.setContentAreaFilled(false);
		anamnesis.setBackground(Color.LIGHT_GRAY);
		anamnesis.setOpaque(true);
		anamnesis.setBorder(null);
		anamnesis.addActionListener(performAction);
		
		showAnamnesisInfo = new JButton("Show Anamnesis");
		showAnamnesisInfo.setFont(font);
		showAnamnesisInfo.setBackground(Color.GRAY);
		showAnamnesisInfo.setOpaque(true);
		showAnamnesisInfo.setBorder(null);
		showAnamnesisInfo.addActionListener(performAction);
		
		viewTest = new JButton("View Test Result");
		viewTest.setFont(font);
		viewTest.setBackground(Color.GRAY);
		viewTest.setOpaque(true);
		viewTest.setBorder(null);
		viewTest.addActionListener(performAction);

		addTResult = new JButton("Add Test Result");
		addTResult.setFont(font);
		addTResult.setBackground(Color.GRAY);
		addTResult.setOpaque(true);
		addTResult.setBorder(null);
		addTResult.addActionListener(performAction);
		
		panel.add(anamnesis);
		panel.add(showAnamnesisInfo);
		panel.add(viewTest);
		panel.add(addTResult);
		
		anamnesisGUIInstance = new AnamnesisGUI(frame).getInstance();
		panel.setLayout(gridLayout);
		frame.setVisible(true);
	}
	class CPanelButtons implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == anamnesis) {
				setButtonColors(anamnesis);
				hidePanels();
				anamnesisGUIInstance = new AnamnesisGUI(frame).getInstance();
			}
			else if(e.getSource() == showAnamnesisInfo) {
				setButtonColors(showAnamnesisInfo);
				hidePanels();
				sAnamnesisInstance = new ShowAnamnesisInfo(frame).getInstance();
			}
			else if(e.getSource() == viewTest) {
				setButtonColors(viewTest);
				hidePanels();
				viewTestInstance = new ViewTest(frame).getInstance();
			}
			else if(e.getSource() == addTResult){
				setButtonColors(addTResult);
				hidePanels();
				addTestResultInstance = new AddTestResult(frame).getInstance();
			}
		}
	}
	private void setButtonColors(JButton buttonName) {
		JButton button2 = null, button3 = null, button4 = null;

		if(buttonName == anamnesis) {
			button2 = showAnamnesisInfo;
			button3 = viewTest;
			button4 = addTResult;
		}
		else if(buttonName == showAnamnesisInfo) {
			button2 = anamnesis;
			button3 = viewTest;
			button4 = addTResult;
		}
		else if(buttonName == viewTest) {
			button2 = anamnesis;
			button3 = showAnamnesisInfo;
			button4 = addTResult;
		}
		else if(buttonName == addTResult){
			button2 = anamnesis;
			button3 = showAnamnesisInfo;
			button4 = viewTest;
		}
		//buttonName.setContentAreaFilled(false);
		buttonName.setBackground(Color.LIGHT_GRAY);
		
		button2.setContentAreaFilled(true);
		button2.setBackground(Color.GRAY);
		
		button3.setContentAreaFilled(true);
		button3.setBackground(Color.GRAY);

		button4.setContentAreaFilled(true);
		button4.setBackground(Color.GRAY);
	}

	public void sendUpdateInfoGUI(){
		new UpdateInfoGUI("nurseFile.txt", name, surname, password, this);
	}

	public void setNewValues(String[] getDivide){
		this.name = getDivide[0];
		this.surname = getDivide[1];
		this.password = getDivide[2];
	}

	private void hidePanels(){
		if(anamnesisGUIInstance != null){
			anamnesisGUIInstance.hidePanel();
			anamnesisGUIInstance = null;
		}
		else if(sAnamnesisInstance != null){
			sAnamnesisInstance.hidePanel();
			sAnamnesisInstance = null;
		}
		else if(viewTestInstance != null){
			viewTestInstance.hidePanel();
			viewTestInstance = null;
		}
		else if(addTestResultInstance != null){
			addTestResultInstance.hidePanel();
			addTestResultInstance = null;
		}
	}

	class MenuItemListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getActionCommand().equals("exit")) {
				frame.setVisible(false);
			}
			else if(e.getActionCommand().equals("updateInformation")) {
				sendUpdateInfoGUI();
			}
			else if(e.getActionCommand().equals("showInformation")) {
				new ShowInfoGUI("nurseFile.txt", name, surname, password);
			}
		}
	}
}