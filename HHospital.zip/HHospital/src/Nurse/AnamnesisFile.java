package Nurse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class AnamnesisFile {
    private String name, surname, gender, pIllnesses, tMedications, diagnosis;
    private long IN, phoneNumber;
    private int age;

    public AnamnesisFile(){}
    public AnamnesisFile(long IN, String name, String surname, int age, long phoneNumber, String gender,
        String pIllnesses, String tMedications, String diagnosis){
        
        this.IN = IN;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
        this.pIllnesses = pIllnesses;
        this.tMedications = tMedications;
        this.diagnosis = diagnosis;
    }

    public int addPatient(){
        long tempIN;
        int control = 0;

        File INFile = new File(System.getProperty("user.dir") + "/patient_anamnesis/patient_ins.txt");
        File file;

        try{
            //control = 1 -> IN match.
            //control = 0 -> IN does not match.
            //control = -1 -> Anamnesis is allready taken.

            if(!INFile.exists())
                INFile.createNewFile();
            Scanner scanINFile = new Scanner(INFile);

            while(scanINFile.hasNextLong()){
                tempIN = scanINFile.nextLong();

                if(IN == tempIN){
                    control = -1;
                    break;
                }
                //System.out.println(tempIN);
            }
            scanINFile.close();
            
            if(control == -1)
                return -1;
            else{
                file = new File(System.getProperty("user.dir") + "/patient_anamnesis/" + IN + ".txt");
                file.createNewFile();

                //Add the new IN to the existing IN file.
                BufferedWriter addIN = new BufferedWriter(new FileWriter(INFile, true));
                addIN.write(IN + "\n");
                addIN.close();
                //End the new IN to the existing IN file.

                BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
                bw.write(IN + "\n");
                bw.write(name + "\n");
                bw.write(surname + "\n");

                bw.write(age + "\n");
                bw.write(phoneNumber + "\n");
                bw.write(gender + "\n");

                bw.write(pIllnesses + "\n");
                bw.write(tMedications + "\n");
                bw.write(diagnosis + "\n\n");
                bw.close();

                return 1;
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return 0;
    }
}