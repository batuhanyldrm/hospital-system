package Nurse;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import HomePage.GUIBuilder;

import java.awt.*;
import java.awt.event.*;

public class AnamnesisGUI {
    Originator originator = new Originator();
    CareTaker careTaker = new CareTaker();

    int backCount = -1;
    private int i = 0, getCState = 1;
    
    private JFrame frame;
    public JPanel title, panel1, cBoxPanel, dILPanel, dInfoPanel, buttonPanel;
    private JTextField IDField, nameField, surnameField, ageField, phoneField, pIField, tMField, dField;
    private JCheckBox maleCBox, femaleCBox;
    private JButton saveButton, clearButton, backButton;

    public AnamnesisGUI(JFrame frame){
        this.frame = frame;
        new GUIBuilder().changeIcon(frame);
        initialize();
    }

    protected AnamnesisGUI getInstance(){
        return this;
    }

    protected void hidePanel(){
        title.setVisible(false);
        panel1.setVisible(false);
        cBoxPanel.setVisible(false);
        dILPanel.setVisible(false);
        dInfoPanel.setVisible(false);
        buttonPanel.setVisible(false);
    }

    private void initialize(){
        title = new JPanel(new GridBagLayout());
        frame.add(title);
        title.setBounds(215, 5, 500, 40);
        title.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints titleConstraint = new GridBagConstraints();
        JLabel anamnesis = new JLabel("Anamnesis Page");
        anamnesis.setFont(new Font("Calibri", Font.BOLD, 30));

        titleConstraint.fill = titleConstraint.HORIZONTAL;
        titleConstraint.gridx = 0;
        titleConstraint.gridy = 0;
        titleConstraint.insets.top = 5;

        title.add(anamnesis, titleConstraint);
        frame.setVisible(true);

        setPanel1();
        setCBoxPanel();
        setDILPanel();
        setPBackgroundPanel();
        setButtonPanel();
    }
    
    private void setPanel1(){
        panel1 = new JPanel(new GridBagLayout());
        frame.add(panel1);
        panel1.setBounds(215, 45, 500, 170);
        panel1.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc1 = new GridBagConstraints();
        Font font = new Font("Calibri", Font.TYPE1_FONT, 20);

        JLabel IDLabel = new JLabel("ID Number:");
        JLabel nameLabel = new JLabel("Name: ");
        JLabel surnameLabel = new JLabel("Surname: ");
        JLabel ageLabel = new JLabel("Age: ");
        JLabel phoneLabel = new JLabel("Phone Number: ");

        IDLabel.setFont(font);
        nameLabel.setFont(font);
        surnameLabel.setFont(font);
        ageLabel.setFont(font);
        phoneLabel.setFont(font);

        IDField = new JTextField(15);
        nameField = new JTextField(15);
        surnameField = new JTextField(15);
        ageField = new JTextField(15);
        phoneField = new JTextField(15);

        new InfoBuilder.Builder().gridX(0).gridY(0).right(10).builder(panel1, IDLabel, gbc1);
        new InfoBuilder.Builder().gridX(1).gridY(0).builder(panel1, IDField, gbc1);
        new InfoBuilder.Builder().gridX(0).gridY(1).right(10).top(5).builder(panel1, nameLabel, gbc1);
        new InfoBuilder.Builder().gridX(1).gridY(1).top(5).builder(panel1, nameField, gbc1);
        new InfoBuilder.Builder().gridX(0).gridY(2).right(10).top(5).builder(panel1, surnameLabel, gbc1);
        new InfoBuilder.Builder().gridX(1).gridY(2).top(5).builder(panel1, surnameField, gbc1);
        new InfoBuilder.Builder().gridX(0).gridY(3).right(10).top(5).builder(panel1, ageLabel, gbc1);
        new InfoBuilder.Builder().gridX(1).gridY(3).top(5).builder(panel1, ageField, gbc1);
        new InfoBuilder.Builder().gridX(0).gridY(4).right(10).top(5).builder(panel1, phoneLabel, gbc1);
        new InfoBuilder.Builder().gridX(1).gridY(4).top(5).builder(panel1, phoneField, gbc1);

        frame.setVisible(true);
    }

    private void setCBoxPanel(){
        cBoxPanel = new JPanel(new GridBagLayout());
        frame.add(cBoxPanel);
        cBoxPanel.setBounds(215, 215, 500, 20);
        cBoxPanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints cbgbc = new GridBagConstraints();
        JLabel genderLabel = new JLabel("Gender: ");
        genderLabel.setFont(new Font("Calibri", Font.TYPE1_FONT, 20));

        maleCBox = new JCheckBox("Male", true);
        femaleCBox = new JCheckBox("Female");

        maleCBox.setBackground(Color.LIGHT_GRAY);
        femaleCBox.setBackground(Color.LIGHT_GRAY);

        maleCBox.addItemListener(new CBoxListener());
        femaleCBox.addItemListener(new CBoxListener());

        new InfoBuilder.Builder().gridX(0).gridY(0).right(65).builder(cBoxPanel, genderLabel, cbgbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).right(40).builder(cBoxPanel, maleCBox, cbgbc);
        new InfoBuilder.Builder().gridX(2).gridY(0).builder(cBoxPanel, femaleCBox, cbgbc);

        frame.setVisible(true);
    }
    
    private void setDILPanel(){
        dILPanel = new JPanel(new GridBagLayout());
        frame.add(dILPanel);
        dILPanel.setBounds(215, 235, 500, 50);
        dILPanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints pblgbc = new GridBagConstraints();
        JLabel pBackgroundLabel = new JLabel("Diagnosis Information");
        pBackgroundLabel.setFont(new Font("Calibri", Font.BOLD, 25));

        new InfoBuilder.Builder().gridX(0).gridY(0).top(20).builder(dILPanel, pBackgroundLabel, pblgbc);
        frame.setVisible(true);
    }

    private void setPBackgroundPanel(){
        dInfoPanel = new JPanel(new GridBagLayout());
        frame.add(dInfoPanel);
        dInfoPanel.setBounds(215, 285, 500, 110);
        dInfoPanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints pbgbc = new GridBagConstraints();
        Font font = new Font("Calibri", Font.TYPE1_FONT, 20);

        JLabel pILabel = new JLabel("Previous Illnesses: ");
        JLabel tMLabel = new JLabel("Taken Medications: ");
        JLabel dLabel = new JLabel("Diagnosis: ");

        pILabel.setFont(font);
        tMLabel.setFont(font);
        dLabel.setFont(font);

        pIField = new JTextField(20);
        tMField = new JTextField(20);
        dField = new JTextField(20);

        new InfoBuilder.Builder().gridX(0).gridY(0).top(10).right(10).builder(dInfoPanel, pILabel, pbgbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).top(10).builder(dInfoPanel, pIField, pbgbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(10).right(10).builder(dInfoPanel, tMLabel, pbgbc);
        new InfoBuilder.Builder().gridX(1).gridY(1).top(10).builder(dInfoPanel, tMField, pbgbc);
        new InfoBuilder.Builder().gridX(0).gridY(2).top(10).right(10).builder(dInfoPanel, dLabel, pbgbc);
        new InfoBuilder.Builder().gridX(1).gridY(2).top(10).builder(dInfoPanel, dField, pbgbc);

        frame.setVisible(true);
    }

    private void setButtonPanel(){
        buttonPanel = new JPanel(new GridBagLayout());
        frame.add(buttonPanel);
        buttonPanel.setBounds(215, 395, 500, 40);
        buttonPanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints bgbc = new GridBagConstraints();

        saveButton = new JButton("Save");
        clearButton = new JButton("Clear");
        backButton = new JButton("Back");

        saveButton.addActionListener(new ButtonListener());
        clearButton.addActionListener(new ButtonListener());
        backButton.addActionListener(new ButtonListener());

        new InfoBuilder.Builder().gridX(0).gridY(0).right(10).left(180).builder(buttonPanel, saveButton, bgbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).right(10).builder(buttonPanel, clearButton, bgbc);
        new InfoBuilder.Builder().gridX(2).gridY(0).builder(buttonPanel, backButton, bgbc);

        frame.setVisible(true);
    }

    private class CBoxListener implements ItemListener{
        public void itemStateChanged(ItemEvent e){
            if(e.getSource() == maleCBox){
                if(e.getStateChange() == 1){
                    getCState = 1;
                    femaleCBox.setSelected(false);
                }
                else{
                    getCState = 0;
                    femaleCBox.setSelected(true);
                }
            }
            else if(e.getSource() == femaleCBox){
                if(e.getStateChange() == 1){
                    getCState = 0;
                    maleCBox.setSelected(false);
                }
                else{
                    getCState = 1;
                    maleCBox.setSelected(true);
                }
            }
        }
    }

    private class ButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent e){
            int getValue = 0;
            int convertAge = 0;
            long convertIN = 0, convertPN = 0;

            String getINField = IDField.getText().trim();
            String getNameField = nameField.getText().trim();
            String getSurnameField = surnameField.getText().trim();

            String getAgeField = ageField.getText().trim();
            String getPNField = phoneField.getText().trim();
            String getGender = null;

            if(getCState == 1)
                getGender = "male";
            else
                getGender = "female";

            String getPIField = pIField.getText().trim();
            String getTMField = tMField.getText().trim();
            String getDField = dField.getText().trim();

            if(e.getSource() == saveButton){
                //Go to file and save the person.

                try{
                    convertIN = Long.parseLong(getINField);
                    convertAge = Integer.parseInt(getAgeField);
                    convertPN = Long.parseLong(getPNField);

                    getValue = new AnamnesisFile(convertIN, getNameField, getSurnameField, convertAge, convertPN, getGender,
                                getPIField, getTMField, getDField).addPatient();

                    if(getValue == 0)
                        JOptionPane.showMessageDialog(frame, "Error occur!");
                    else if(getValue == 1)
                        JOptionPane.showMessageDialog(frame, "The patient added.");
                    else if(getValue == -1)
                        JOptionPane.showMessageDialog(frame, "The anamnesis is allready taken.");
                }
                catch(Exception exception){
                    JOptionPane.showMessageDialog(frame, "Unvalid character usage! Please check the ID, \nage and phone number fields again.");
                }
            }

            else if(e.getSource() == clearButton){
                //Set null the fields and write info to memento.
                originator.setState(getINField, getNameField, getSurnameField, getAgeField, getPNField, getGender,
                                    getPIField, getTMField, getDField);

                careTaker.add(originator.saveStateMemento());

                IDField.setText(null);
                nameField.setText(null);
                surnameField.setText(null);

                ageField.setText(null);
                phoneField.setText(null);
                
                maleCBox.setSelected(true);
                femaleCBox.setSelected(false);

                pIField.setText(null);
                tMField.setText(null);
                dField.setText(null);

                backCount++;
            }

            else if(e.getSource() == backButton){
                //Call info from memento.
                if(backCount > -1){
                    originator.getStateFromMemento(careTaker.get(backCount));
                    String getValues = originator.getState();
                    
                    String[] array = getValues.split("#", 9);
                    
                    IDField.setText(array[0]);
                    nameField.setText(array[1]);
                    surnameField.setText(array[2]);

                    ageField.setText(array[3]);
                    phoneField.setText(array[4]);
                    
                    if(array[5].equals("male")){
                        maleCBox.setSelected(true);
                        femaleCBox.setSelected(false);
                    }
                    else{
                        maleCBox.setSelected(false);
                        femaleCBox.setSelected(true);
                    }

                    pIField.setText(array[6]);
                    tMField.setText(array[7]);
                    dField.setText(array[8]);

                    backCount--;
                }
            }
        }
    }
}