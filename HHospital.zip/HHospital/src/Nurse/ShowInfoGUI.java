package Nurse;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import HomePage.GUIBuilder;

public class ShowInfoGUI {
	private JFrame frame;
	private JPanel firstPanel;
	
	private String name = null, surname = null, password = null;
	private String getEmployeeInfo = null;
	private String iN = null, phoneNumber = null, birthDate = null, gender = null;
	private String fileName = null;
	
	public ShowInfoGUI(String fileName, String name, String surname, String password) {
		this.fileName = fileName;
		this.name = name;
		this.surname = surname;
		this.password = password;
		
		getEmployeeInfo = new ShowInfoFile(fileName, name, surname, password).returnInfo();
		initialize();
	}
	private void initialize() {
		String[] splitInfo = getEmployeeInfo.split("@", 6);
		iN = splitInfo[0];
		name = splitInfo[1];
		surname = splitInfo[2];
		birthDate = splitInfo[3];
		gender = splitInfo[4];
		phoneNumber = splitInfo[5];
		
		frame = new JFrame();
		frame.setTitle("Information Page");
		frame.setBounds(350, 100, 480, 400);
		
		frame.setResizable(false);
		frame.setVisible(true);
		new GUIBuilder().changeIcon(frame);
		
		setFirstPanel();
	}
	private void setFirstPanel() {
		firstPanel = new JPanel(new GridBagLayout());
		frame.add(firstPanel);
		
		GridBagConstraints gbc = new GridBagConstraints();
		Font labelFont = new Font("Calibri", Font.BOLD, 25);
		Font valueFont = new Font("Calibri", Font.ITALIC, 20);
		
		JLabel info = new JLabel("Your Informations");
		info.setFont(new Font("Calibri", Font.BOLD, 35));
		
		JLabel nameLabel = new JLabel("Name: ");
		JLabel surnameLabel = new JLabel("Surame: ");
		JLabel bDateLabel = new JLabel("Birth Date: ");
		JLabel genderLabel = new JLabel("Gender: ");
		JLabel iNLabel = new JLabel("Identification Number: ");
		JLabel phoneNumberLabel = new JLabel("Phone Number: ");
		
		JLabel nameValue = new JLabel(name);
		JLabel surnameValue = new JLabel(surname);
		JLabel bDateValue = new JLabel(birthDate);
		JLabel genderValue = new JLabel(gender);
		JLabel iNValue = new JLabel(iN);
		JLabel phoneNumberValue = new JLabel(phoneNumber);
		
		nameLabel.setFont(labelFont);
		surnameLabel.setFont(labelFont);
		bDateLabel.setFont(labelFont);
		genderLabel.setFont(labelFont);
		iNLabel.setFont(labelFont);
		phoneNumberLabel.setFont(labelFont);
		
		nameValue.setFont(valueFont);
		surnameValue.setFont(valueFont);
		bDateValue.setFont(valueFont);
		genderValue.setFont(valueFont);
		iNValue.setFont(valueFont);
		phoneNumberValue.setFont(valueFont);
		
		new InfoBuilder.Builder().gridX(0).gridY(0).right(10).bottom(20).builder(firstPanel, info, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(1).top(10).right(10).builder(firstPanel, iNLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(1).top(10).builder(firstPanel, iNValue, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(2).right(10).top(10).builder(firstPanel, nameLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(2).top(10).builder(firstPanel, nameValue, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(3).right(10).top(10).builder(firstPanel, surnameLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(3).top(10).builder(firstPanel, surnameValue, gbc);
		
		new InfoBuilder.Builder().gridX(0).gridY(4).right(10).top(10).builder(firstPanel, bDateLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(4).top(10).builder(firstPanel, bDateValue, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(5).right(10).top(10).builder(firstPanel, genderLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(5).top(10).builder(firstPanel, genderValue, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(6).top(10).right(10).builder(firstPanel, phoneNumberLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(6).top(10).builder(firstPanel, phoneNumberValue, gbc);
		
		frame.setVisible(true);
	}
}