package Nurse;

import javax.swing.JFrame;

public class NurseSingleton extends JFrame{
	private NurseSingleton frame = null;
	NurseSingleton(){}
	
	private void createFrame() {
		frame = new NurseSingleton();
	}
	public JFrame getFrame() {
		if(frame == null)
			createFrame();
		
		return frame;
	}
}