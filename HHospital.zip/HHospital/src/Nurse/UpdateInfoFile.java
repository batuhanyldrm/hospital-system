package Nurse;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class UpdateInfoFile {
	private long phoneNumber = 0, iN = 0;
	private String name = null, surname = null, password = null;
	private String securityAns = null, birthDate = null, gender = null;
	private String fileName = null;
	
	private int control = 0;
	private String tempName = null, tempSurname = null, tempPassword = null;
	private String tempSecurityAns = null, tempBirthDate = null, tempGender = null;
	private long tempPhoneNumber = 0, tempIN = 0;
	
	public UpdateInfoFile(String fileName, String name, String surname, String password) {
		this.fileName = fileName;
		this.name = name;
		this.surname = surname;
		this.password = password;
	}
	
	public UpdateInfoFile(String fileName, long iN, String name, String surname, String password, String birthDate,
					String gender, long phoneNumber, String securityAns) {

		this.fileName = fileName;
		this.iN = iN;
		this.name = name;
		this.surname = surname;
		this.password = password;
		this.birthDate = birthDate;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.securityAns = securityAns;
	}
	
	public String returnInfo() {
		String convertIN = null, convertPhoneNumber = null;
		File file = new File(fileName);
		
		try {
			Scanner scan = new Scanner(file);
			
			while(scan.hasNextLine()) {				
				tempIN = scan.nextInt();
				
				scan.nextLine();
				tempName = scan.nextLine();
				
				tempSurname = scan.next();
				tempPassword = scan.next();
				tempBirthDate = scan.next();
				tempGender = scan.next();
				
				tempPhoneNumber = scan.nextLong();
				scan.nextLine();
				
				tempSecurityAns = scan.nextLine();
				scan.nextLine();
				
				if(name.equals(tempName) && surname.equals(tempSurname) && password.equals(tempPassword)) {
					break;
				}
			}
			control = 0;
			convertIN = String.valueOf(tempIN);
			convertPhoneNumber = String.valueOf(tempPhoneNumber);
			
			scan.close();
			return convertIN + "@" + tempBirthDate + "@" + tempGender + "@" + convertPhoneNumber + "@" + tempSecurityAns;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String updateInfo(String getPName, String getPSurname, String getPPassword) {
		String returnValue = null;
		File file = new File(fileName);
		File tempFile = new File("temp" + fileName);
		//File tempFile = new File("tempNurse.txt");
		
		try {
			Scanner scan = new Scanner(file);
			BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile, true));
			
			while(scan.hasNextLine()) {				
				tempIN = scan.nextInt();
				
				scan.nextLine();
				tempName = scan.nextLine();
				
				tempSurname = scan.next();
				tempPassword = scan.next();
				tempBirthDate = scan.next();
				tempGender = scan.next();

				tempPhoneNumber = scan.nextLong();
				scan.nextLine();

				tempSecurityAns = scan.nextLine();
				scan.nextLine();
				
				if(getPName.equals(tempName) && getPSurname.equals(tempSurname) && getPPassword.equals(tempPassword)) {
					bw.write(iN + "\n" + name + "\n" + surname + "\n" + password + "\n" + birthDate + "\n");
					bw.write(gender + "\n" + phoneNumber + "\n" + securityAns + "\n\n");

					returnValue = name + "@" + surname + "@" + password;
				}
				else {
					bw.write(tempIN + "\n" + tempName + "\n" + tempSurname + "\n" + tempPassword + "\n" + tempBirthDate + "\n");
					bw.write(tempGender + "\n" + tempPhoneNumber + "\n" + tempSecurityAns + "\n\n");
				}
			}
			
			control = 0;
			scan.close();
			bw.close();
			file.delete();
			tempFile.renameTo(file);
			
			return returnValue;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}
}