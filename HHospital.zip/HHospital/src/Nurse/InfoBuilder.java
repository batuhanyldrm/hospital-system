package Nurse;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JComponent;
import javax.swing.JPanel;

public class InfoBuilder {
	public InfoBuilder(){}
	public void initiate() {}
	
	public InfoBuilder(Builder builder, JPanel panel, JComponent component, GridBagConstraints gbc){
		if(builder.setAlignment == 0)
			gbc.fill = GridBagConstraints.HORIZONTAL;
		else 
			gbc.fill = GridBagConstraints.VERTICAL;
			
		
		gbc.gridx = builder.gridX;
		gbc.gridy = builder.gridY;
		
		gbc.insets = new Insets(builder.top, builder.left, builder.bottom, builder.right);
		gbc.ipadx = builder.iPadX;
		gbc.ipady = builder.iPadY;
		
		if(builder.gridHeight > 0) {
			gbc.gridheight = builder.gridHeight;
		}
		else if(builder.gridWidth > 0){
			gbc.gridwidth = builder.gridWidth;
		}
		
		panel.add(component, gbc);
	}
	
	public static class Builder{
		private int gridX = 0, gridY = 0, top = 0, left = 0, bottom = 0, right = 0, iPadX = 0, iPadY = 0, setAlignment = 0;
		private int gridWidth = 0, gridHeight = 0;
		public Builder(){}
		
		public Builder gridX(int gridX) {
			this.gridX = gridX;
			return this;
		}
		public Builder gridY(int gridY) {
			this.gridY = gridY;
			return this;
		}
		public Builder top(int top) {
			this.top = top;
			return this;
		}
		public Builder left(int left) {
			this.left = left;
			return this;
		}
		public Builder bottom(int bottom) {
			this.bottom = bottom;
			return this;
		}
		public Builder right(int right) {
			this.right = right;
			return this;
		}
		public Builder iPadX(int iPadX) {
			this.iPadX = iPadX;
			return this;
		}
		public Builder iPadY(int iPadY) {
			this.iPadY = iPadY;
			return this;
		}
		public Builder setAlignment(int setAlignment) {
			if(setAlignment < 0 || setAlignment > 1) {
				System.out.println("Set alignment must between 0 and 1.");
				return null;
			}
				
			this.setAlignment = setAlignment;
			return this;
		}
		public Builder gridWidth(int gridWidth) {
			this.gridWidth = gridWidth;
			return this;
		}
		public Builder gridHeight(int gridHeight) {
			this.gridHeight = gridHeight;
			return this;
		}
		public InfoBuilder builder(JPanel panel, JComponent component, GridBagConstraints gbc) {
			return new InfoBuilder(this, panel, component, gbc);
		}
	}
}