package Nurse;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import HomePage.GUIBuilder;

public class UpdateInfoGUI {
	public String[] divide;
	NurseGUI nurse;

	private JFrame frame;
	private JPanel titlePanel, firstPanel, secondPanel;
	private JTextField nameField, surnameField, iNField, phoneNumberField, sAns1, bDateField, genderField;
	private JPasswordField fPassField, sPassField;
	private JCheckBox showSQuestions;
	
	private String name = null, surname = null, password = null;
	private String getEmployeeInfo = null;
	private String iN = null, phoneNumber = null, secAns, birthDate = null, gender = null;
	private String fileName = null;
	private int controlCheckBox = 0;
	
	public UpdateInfoGUI(String fileName, String name, String surname, String password, NurseGUI nurse) {
		this.fileName = fileName;
		this.name = name;
		this.surname = surname;
		this.password = password;

		this.nurse = nurse;
		
		getEmployeeInfo = new UpdateInfoFile(fileName, name, surname, password).returnInfo();
		initialize();
	}
	
	private void initialize() {
		String[] splitInfo = getEmployeeInfo.split("@", 5);
		iN = splitInfo[0];
		birthDate = splitInfo[1];
		gender = splitInfo[2];
		phoneNumber = splitInfo[3];
		secAns = splitInfo[4];
		
		frame = new JFrame();
		frame.setTitle("Information Exchange Page");
		frame.setLayout(null);
		frame.setBounds(350, 100, 450, 460);
		frame.setResizable(false);
		
		frame.setVisible(true);
		new GUIBuilder().changeIcon(frame);
		
		titlePanel();
		setMenuBar();
		setFirstPanel();
	}
	private void titlePanel() {
		titlePanel = new JPanel(new GridBagLayout());
		frame.add(titlePanel);
		
		titlePanel.setBounds(0, 0, 450, 70);
		titlePanel.setBackground(Color.LIGHT_GRAY);
		
		JLabel titleLabel = new JLabel("Update Information");
		titleLabel.setFont(new Font("Calibri", Font.BOLD, 30));
		
		GridBagConstraints titleGbc = new GridBagConstraints();
		new InfoBuilder.Builder().gridX(0).gridY(0).builder(titlePanel, titleLabel, titleGbc);

		frame.setVisible(true);
	}
	private void setMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu options = new JMenu("Options");
		JMenuItem saveButton = new JMenuItem("Save");
		
		saveButton.setActionCommand("saveButton");
		options.add(saveButton);
		menuBar.add(options);
		
		AddAction action = new AddAction();
		saveButton.addActionListener(action);
		
		frame.setJMenuBar(menuBar);
		frame.setVisible(true);
	}
	private void setFirstPanel() {
		firstPanel = new JPanel(new GridBagLayout());
		frame.add(firstPanel);
		firstPanel.setBounds(0, 70, 450, 330);
		firstPanel.setBackground(Color.LIGHT_GRAY);
		
		GridBagConstraints gbc = new GridBagConstraints();
		Font labelFont = new Font("Calibri", Font.BOLD, 20);
		
		JLabel iNLabel = new JLabel("Identification Number: ");
		JLabel nameLabel = new JLabel("Name: ");
		JLabel surnameLabel = new JLabel("Surame: ");
		JLabel bDateLabel = new JLabel("Birth Date: ");
		JLabel genderLabel = new JLabel("Gender: ");
		JLabel phoneNumberLabel = new JLabel("Phone Number: ");
		JLabel fPLabel = new JLabel("Password: ");
		JLabel sPLabel = new JLabel("Repeat the Password: ");
		
		nameLabel.setFont(labelFont);
		surnameLabel.setFont(labelFont);
		iNLabel.setFont(labelFont);
		phoneNumberLabel.setFont(labelFont);
		fPLabel.setFont(labelFont);
		sPLabel.setFont(labelFont);
		bDateLabel.setFont(labelFont);
		genderLabel.setFont(labelFont);
		
		iNField = new JTextField(iN, 15);
		nameField = new JTextField(name, 15);
		surnameField = new JTextField(surname, 15);
		bDateField = new JTextField(birthDate, 15);
		genderField = new JTextField(gender, 15);
		phoneNumberField = new JTextField(phoneNumber, 15);
		fPassField = new JPasswordField(password, 15);
		sPassField = new JPasswordField(password, 15);
		
		new InfoBuilder.Builder().gridX(0).gridY(0).right(10).builder(firstPanel, iNLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(0).builder(firstPanel, iNField, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(1).right(10).top(10).builder(firstPanel, nameLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(1).top(10).builder(firstPanel, nameField, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(2).right(10).top(10).builder(firstPanel, surnameLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(2).top(10).builder(firstPanel, surnameField, gbc);

		new InfoBuilder.Builder().gridX(0).gridY(3).top(10).right(10).builder(firstPanel, bDateLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(3).top(10).builder(firstPanel, bDateField, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(4).top(10).right(10).builder(firstPanel, genderLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(4).top(10).builder(firstPanel, genderField, gbc);

		new InfoBuilder.Builder().gridX(0).gridY(5).right(10).top(10).builder(firstPanel, phoneNumberLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(5).top(10).builder(firstPanel, phoneNumberField, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(6).right(10).top(10).builder(firstPanel, fPLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(6).top(10).builder(firstPanel, fPassField, gbc);
		new InfoBuilder.Builder().gridX(0).gridY(7).right(10).top(10).builder(firstPanel, sPLabel, gbc);
		new InfoBuilder.Builder().gridX(1).gridY(7).top(10).builder(firstPanel, sPassField, gbc);
		
		JCheckBox showSQuestions = new JCheckBox("Change the security questions.");
		showSQuestions.setBackground(Color.LIGHT_GRAY);
		
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 8;
		gbc.insets.top = 15;
		firstPanel.add(showSQuestions, gbc);
		
		showSQuestions.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == 1) {
					controlCheckBox = 1;
					setSecondPanel();
				}
				else {
					controlCheckBox = 0;
					secondPanel.setVisible(false);
					frame.setBounds(350, 100, 450, 460);
				}
			}
		});
		
		frame.setVisible(true);
	}
	public void setSecondPanel() {
		frame.setBounds(350, 100, 450, 580);
		secondPanel = new JPanel(new GridBagLayout());
		frame.add(secondPanel);
		
		secondPanel.setBounds(0, 400, 450, 120);
		secondPanel.setBackground(Color.LIGHT_GRAY);
		
		GridBagConstraints gbc2 = new GridBagConstraints();
		
		String[] addQuestions = new String[5];
		addQuestions[0] = "What was your childhood nickname?";
		addQuestions[1] = "What is the name of your favorite childhood friend?";
		addQuestions[2] = "What was your dream job as a child?";
		addQuestions[3] = "Who was your childhood hero?";
		addQuestions[4] = "In what city and country do you want to retire?";
		
		JLabel info = new JLabel("(Please answer the security questions.)");
		sAns1 = new JTextField(15);
		
		sAns1.setText(null);
		
		JComboBox firstQuestion = new JComboBox(addQuestions);
		firstQuestion.setSelectedIndex(0);
		
		new InfoBuilder.Builder().gridX(0).gridY(0).builder(secondPanel, info, gbc2);		
		new InfoBuilder.Builder().gridX(0).gridY(1).top(10).builder(secondPanel, firstQuestion, gbc2);
		new InfoBuilder.Builder().gridX(0).gridY(2).top(5).builder(secondPanel, sAns1, gbc2);

		frame.setVisible(true);
	}

	private class AddAction implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			String getReturnValue = null;
			
			String getSAns = null;
			
			String getIN = iNField.getText().trim();
			String getPhoneNumber = phoneNumberField.getText().trim();
			
			String getName = nameField.getText().trim();
			String getSurname = surnameField.getText().trim();
			String getFirstPassword = new String(fPassField.getPassword());
			String getSecondPassword = new String(sPassField.getPassword());

			String getBDate = bDateField.getText().trim();
			String getGender = genderField.getText().trim();

			if(controlCheckBox == 0) {
				getSAns = secAns;
			}
			else {
				getSAns = sAns1.getText();
				
				if(getSAns.equals(""))
					getSAns = secAns;
			}
			
			//Return this file to UpdateInfoFile.
			if(!getFirstPassword.equals(getSecondPassword))
				JOptionPane.showMessageDialog(frame, "The password fields does not match. Please check the fields again.");
			else {
				long convertIN = Long.parseLong(getIN);
				long convertPhoneNumber = Long.parseLong(getPhoneNumber);
				
				getReturnValue = new UpdateInfoFile("nurseFile.txt", convertIN, getName, getSurname, getFirstPassword, getBDate, getGender,
						convertPhoneNumber, getSAns).updateInfo(name, surname, password);
				
				if(getReturnValue == null)
					JOptionPane.showMessageDialog(frame, "Error occured!");
				else
					JOptionPane.showMessageDialog(frame, "Your information successfully changed.");

				divide = getReturnValue.split("@", 3);
				nurse.setNewValues(divide);
				//new NurseGUI(divide);
			}
		}
	}
}