package Nurse;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.*;
import java.awt.event.*;

import HomePage.GUIBuilder;

public class ShowAnamnesisInfo {
    int mouseClick = 0;
    private String IN, name, surname, age, phoneNumber, gender, pIllnesses, tMedications, diagnosis;

    private JFrame frame;
    private JPanel emptyPanel, contentPanel, titlePanel, panel, sTitlePanel, secondPanel;
    private JLabel setIN, setName, setSurname, setAge, setPhoneNumber, setGender;
    private JLabel setPIllnesses, setTMedications, setDiagnosis;
    private JButton okButton;
    private JTextField INField;

    public ShowAnamnesisInfo(JFrame frame){
        this.frame = frame;
        new GUIBuilder().changeIcon(frame);
        initiate();
    }

    public ShowAnamnesisInfo getInstance(){
        return this;
    }

    protected void hidePanel(){
        titlePanel.setVisible(false);
        contentPanel.setVisible(false);
        emptyPanel.setVisible(false);

        if(panel != null)
            panel.setVisible(false);
        if(sTitlePanel != null)
            sTitlePanel.setVisible(false);
        if(secondPanel != null)
            secondPanel.setVisible(false);
    }

    private void initiate(){
        titlePanel = new JPanel(new GridBagLayout());
        frame.add(titlePanel);
        titlePanel.setBounds(215, 5, 500, 40);
        titlePanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints tgbc = new GridBagConstraints();
        JLabel titleLabel = new JLabel("Show Anamnesis");

        titleLabel.setFont(new Font("Calibri", Font.BOLD, 30));
        new InfoBuilder.Builder().gridX(0).gridY(0).top(5).builder(titlePanel, titleLabel, tgbc);

        frame.setVisible(true);
        setContentTitlePanel();
        setEmptyPanel();
    }

    private void setContentTitlePanel(){
        contentPanel = new JPanel(new GridBagLayout());
        frame.add(contentPanel);
        contentPanel.setBounds(215, 45, 500, 100);
        contentPanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        JLabel INLabel = new JLabel("Identification Number of the Patient");
        INLabel.setFont(new Font("Calibri", Font.TYPE1_FONT, 20));

        INField = new JTextField(15);
        okButton = new JButton("OK");
        okButton.addActionListener(new MouseAction());

        new InfoBuilder.Builder().gridX(0).gridY(0).top(10).right(10).builder(contentPanel, INLabel, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(5).builder(contentPanel, INField, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(2).top(5).builder(contentPanel, okButton, gbc);

        frame.setVisible(true);
    }

    private void setEmptyPanel(){
        emptyPanel = new JPanel();
        frame.add(emptyPanel);
        emptyPanel.setBounds(215, 145, 500, 290);
        emptyPanel.setBackground(Color.LIGHT_GRAY);
        frame.setVisible(true);
    }

    private void setPanel(){
        panel = new JPanel(new GridBagLayout());
        frame.add(panel);
        panel.setBounds(215, 45, 500, 170);
        panel.setBackground(Color.LIGHT_GRAY);

        Font font = new Font("Calibri", Font.TYPE1_FONT, 20);
        Font secondFont = new Font("Calibri", Font.ITALIC, 20);
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel INLabel = new JLabel("Identification Number: ");
        JLabel nameLabel = new JLabel("Name: ");
        JLabel surnameLabel = new JLabel("Surname: ");
        JLabel ageLabel = new JLabel("Age: ");
        JLabel phoneNumberLabel = new JLabel("Phone Number: ");
        JLabel genderLabel = new JLabel("Gender: ");

        INLabel.setFont(font);
        nameLabel.setFont(font);
        surnameLabel.setFont(font);
        ageLabel.setFont(font);
        phoneNumberLabel.setFont(font);
        genderLabel.setFont(font);

        setIN = new JLabel(IN);
        setName = new JLabel(name);
        setSurname = new JLabel(surname);
        setAge = new JLabel(age);
        setPhoneNumber = new JLabel(phoneNumber);
        setGender = new JLabel(gender);

        setIN.setFont(secondFont);
        setName.setFont(secondFont);
        setSurname.setFont(secondFont);
        setAge.setFont(secondFont);
        setPhoneNumber.setFont(secondFont);
        setGender.setFont(secondFont);

        new InfoBuilder.Builder().gridX(0).gridY(0).right(10).builder(panel, INLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).builder(panel, setIN, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(5).right(10).builder(panel, nameLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(1).top(5).builder(panel, setName, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(2).top(5).right(10).builder(panel, surnameLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(2).top(5).builder(panel, setSurname, gbc);

        new InfoBuilder.Builder().gridX(0).gridY(3).top(5).right(10).builder(panel, ageLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(3).top(5).builder(panel, setAge, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(4).top(5).right(10).builder(panel, phoneNumberLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(4).top(5).builder(panel, setPhoneNumber, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(5).top(5).right(10).builder(panel, genderLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(5).top(5).builder(panel, setGender, gbc);

        frame.setVisible(true);
        setSecondTitlePanel();
        setSecondPanel();
    }

    private void setSecondTitlePanel(){
        sTitlePanel = new JPanel(new GridBagLayout());
        frame.add(sTitlePanel);
        sTitlePanel.setBounds(215, 215, 500, 40);
        sTitlePanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        JLabel titleLabel = new JLabel("Diagnosis Info");
        titleLabel.setFont(new Font("Calibri", Font.BOLD, 25));

        new InfoBuilder.Builder().gridX(0).gridY(0).top(20).builder(sTitlePanel, titleLabel, gbc);
        frame.setVisible(true);
    }

    private void setSecondPanel(){
        secondPanel = new JPanel(new GridBagLayout());
        frame.add(secondPanel);
        secondPanel.setBounds(215, 255, 500, 180);
        secondPanel.setBackground(Color.LIGHT_GRAY);

        Font font = new Font("Calibri", Font.TYPE1_FONT, 20);
        Font secondFont = new Font("Calibri", Font.ITALIC, 20);
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel pIllnessesLabel = new JLabel("Previous Illnesses: ");
        JLabel tMedicationsLabel = new JLabel("Taken Medications: ");
        JLabel diagnosisLabel = new JLabel("Diagnosis: ");

        pIllnessesLabel.setFont(font);
        tMedicationsLabel.setFont(font);
        diagnosisLabel.setFont(font);

        setPIllnesses = new JLabel(pIllnesses);
        setTMedications = new JLabel(tMedications);
        setDiagnosis = new JLabel(diagnosis);

        setPIllnesses.setFont(secondFont);
        setTMedications.setFont(secondFont);
        setDiagnosis.setFont(secondFont);

        okButton = new JButton("OK");
        okButton.addActionListener(new MouseAction());

        new InfoBuilder.Builder().gridX(0).gridY(0).right(10).builder(secondPanel, pIllnessesLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).builder(secondPanel, setPIllnesses, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(5).right(10).builder(secondPanel, tMedicationsLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(1).top(5).builder(secondPanel, setTMedications, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(2).top(5).right(10).builder(secondPanel, diagnosisLabel, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(2).top(5).builder(secondPanel, setDiagnosis, gbc);
        new InfoBuilder.Builder().gridX(1).gridY(3).top(5).builder(secondPanel, okButton, gbc);

        frame.setVisible(true);
    }

    private void buttonOn(){
        String getValues;
        String getIN = INField.getText().trim();

        if(getIN.equals(""))
            JOptionPane.showMessageDialog(frame, "You must enter the patient's identification number \nto be able to see the wish test.");
        else{
            long convertIN = Long.parseLong(getIN);
            getValues = new ShowAnamnesisFile(convertIN).returnInfo();

            if(getValues == null)
                JOptionPane.showMessageDialog(frame, "Wrong identification number. Please check it again.");
            else{
                mouseClick = 1;
                contentPanel.setVisible(false);
                emptyPanel.setVisible(false);

                String[] splitInfo = getValues.split("@", 9);
                this.IN = splitInfo[0];
                this.name = splitInfo[1];
                this.surname = splitInfo[2];

                this.age = splitInfo[3];
                this.phoneNumber = splitInfo[4];
                this.gender = splitInfo[5];

                this.pIllnesses = splitInfo[6];
                this.tMedications = splitInfo[7];
                this.diagnosis = splitInfo[8];
                setPanel();
            }
        }
    }

    private class MouseAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(mouseClick == 0){
                buttonOn();
            }
            else{
                mouseClick = 0;
                panel.setVisible(false);
                sTitlePanel.setVisible(false);;
                secondPanel.setVisible(false);;

                titlePanel.setVisible(false);
                initiate();
            }
        }
    }
}