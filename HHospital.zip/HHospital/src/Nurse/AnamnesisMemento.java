package Nurse;

import java.util.ArrayList;
import java.util.List;

public class AnamnesisMemento {
    //Values.
    private String IN, name, surname, age, phonenumber, gender, pIllnesses, tMedications, diagnosis;

    public AnamnesisMemento(String IN, String name, String surname, String age, String phoneNumber, String gender,
                            String pIllnesses, String tMedications, String diagnosis){

        this.IN = IN;
        this.name = name;
        this.surname = surname;

        this.age = age;
        this.phonenumber = phoneNumber;
        this.gender = gender;
        
        this.pIllnesses = pIllnesses;
        this.tMedications = tMedications;
        this.diagnosis = diagnosis;
    }
    public String getState(){
        return IN + "#" + name + "#" + surname + "#" + age + "#" + phonenumber + "#" + gender + "#"
                + pIllnesses + "#" +tMedications + "#" + diagnosis;
    }
}

class Originator{
    private String state;
    private String IN, name, surname, age, phoneNumber, gender, pIllnesses, tMedications, diagnosis;

    public void setState(String IN, String name, String surname, String age, String phoneNumber, String gender,
                        String pIllnesses, String tMedications, String diagnosis){
        this.IN = IN;
        this.name = name;
        this.surname = surname;

        this.age = age;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
        
        this.pIllnesses = pIllnesses;
        this.tMedications = tMedications;
        this.diagnosis = diagnosis;
    }

    public String getState(){
        return this.state;
    }

    public AnamnesisMemento saveStateMemento(){
        return new AnamnesisMemento(IN, name, surname, age, phoneNumber, gender, pIllnesses, tMedications, diagnosis);
    }

    public void getStateFromMemento(AnamnesisMemento memento){
        state = memento.getState();
        String[] divide = state.split("#", 9);

        IN = divide[0];
        name = divide[1];
        surname = divide[2];

        age = divide[3];
        phoneNumber = divide[4];
        gender = divide[5];
        
        pIllnesses = divide[6];
        tMedications = divide[7];
        diagnosis = divide[8];
    }
}

class CareTaker{
    private List<AnamnesisMemento> mementoList = new ArrayList<AnamnesisMemento>();

    public void add(AnamnesisMemento state){
        mementoList.add(state);
    }
    public AnamnesisMemento get(int index){
        return mementoList.get(index);
    }
}