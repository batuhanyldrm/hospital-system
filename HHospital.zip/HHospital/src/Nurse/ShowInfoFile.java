package Nurse;

import java.io.File;
import java.util.Scanner;

public class ShowInfoFile {
	private String name = null, surname = null, password = null;
	private String iN = null, phoneNumber = null, securityAns1 = null;
	private String fileName = null;
	
	private String tempName = null, tempSurname = null, tempPassword = null;
	private String tempSecurityAns = null, tempBirthDate = null, tempGender = null;
	private long tempPhoneNumber = 0, tempIN = 0;
	
	public ShowInfoFile(String fileName, String name, String surname, String password) {
		this.fileName = fileName;
		this.name = name;
		this.surname = surname;
		this.password = password;
	}
	public String returnInfo() {
		String convertIN = null, convertPhoneNumber = null;
		File file = new File(fileName);
		
		try {
			Scanner scan = new Scanner(file);
			
			while(scan.hasNextLine()) {				
				tempIN = scan.nextLong();
				
				scan.nextLine();
				tempName = scan.nextLine();
				
				tempSurname = scan.next();
				tempPassword = scan.next();
				
				tempBirthDate = scan.next();
				tempGender = scan.next();
				//Phone number.
				tempPhoneNumber = scan.nextLong();
				scan.nextLine();
				
				tempSecurityAns = scan.nextLine();
				scan.nextLine();
				
				if(name.equals(tempName) && surname.equals(tempSurname) && password.equals(tempPassword)) {
					break;
				}
			}
			convertIN = String.valueOf(tempIN);
			convertPhoneNumber = String.valueOf(tempPhoneNumber);
			
			scan.close();
			return convertIN + "@" + tempName + "@" + tempSurname + "@" + tempBirthDate + "@" + tempGender + "@" + convertPhoneNumber;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}