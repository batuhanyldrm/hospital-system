package Nurse;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*;
import java.awt.event.*;

import HomePage.GUIBuilder;

public class ViewTest {
    private int clickCount = 0;

    private JFrame frame;
    private JPanel titlePanel, panel, emptyPanel, secondPanel, sEPanel;
    private JTextField INField;
    private JButton okButton;
    private JLabel setIN, setName, setSurname, setTest, setTestResult;
    private String IN, name, surname, testName, testResult;

    public ViewTest(JFrame frame){
        this.frame = frame;
        new GUIBuilder().changeIcon(frame);
        initialize();
    }

    protected ViewTest getInstance(){
        return this;
    }

    protected void hidePanel(){
        titlePanel.setVisible(false);
        panel.setVisible(false);
        emptyPanel.setVisible(false);

        if(secondPanel != null)
            secondPanel.setVisible(false);
        if(sEPanel != null)
            sEPanel.setVisible(false);
    }

    private void initialize(){
        titlePanel = new JPanel(new GridBagLayout());
        frame.add(titlePanel);
        titlePanel.setBounds(215, 5, 500, 40);
        titlePanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints tgbc = new GridBagConstraints();
        JLabel titleLabel = new JLabel("View Test Result");

        titleLabel.setFont(new Font("Calibri", Font.BOLD, 30));
        new InfoBuilder.Builder().gridX(0).gridY(0).top(5).builder(titlePanel, titleLabel, tgbc);

        frame.setVisible(true);
        setPanel();
        setEmptyPanel();
    }

    private void setPanel(){
        panel = new JPanel(new GridBagLayout());
        frame.add(panel);
        panel.setBounds(215, 45, 500, 100);
        panel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints gbc = new GridBagConstraints();
        JLabel INLabel = new JLabel("Identification Number of the Patient");
        INLabel.setFont(new Font("Calibri", Font.TYPE1_FONT, 20));

        INField = new JTextField(15);
        okButton = new JButton("OK");
        okButton.addActionListener(new MouseAction());

        new InfoBuilder.Builder().gridX(0).gridY(0).top(10).right(10).builder(panel, INLabel, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(5).builder(panel, INField, gbc);
        new InfoBuilder.Builder().gridX(0).gridY(2).top(5).builder(panel, okButton, gbc);

        frame.setVisible(true);
    }

    private void setEmptyPanel(){
        emptyPanel = new JPanel();
        frame.add(emptyPanel);
        emptyPanel.setBounds(215, 145, 500, 290);
        emptyPanel.setBackground(Color.LIGHT_GRAY);
        frame.setVisible(true);
    }

    private void setSecondPanel(){
        secondPanel = new JPanel(new GridBagLayout());
        frame.add(secondPanel);
        secondPanel.setBounds(215, 45, 500, 220);
        secondPanel.setBackground(Color.LIGHT_GRAY);

        GridBagConstraints spgbc = new GridBagConstraints();
        Font font = new Font("Calibri", Font.BOLD, 20);
        Font font2 = new Font("Calibri", Font.ITALIC, 19);

        JLabel INLabel = new JLabel("Identification Number: ");
        JLabel nameLabel = new JLabel("Name: ");
        JLabel surnameLabel = new JLabel("Surname: ");
        JLabel testLabel = new JLabel("Test: ");
        JLabel testResultLabel = new JLabel("Test Result: ");

        setIN = new JLabel(IN);
        setName = new JLabel(name);
        setSurname = new JLabel(surname);
        setTest = new JLabel(testName);
        setTestResult = new JLabel(testResult);

        INLabel.setFont(font);
        nameLabel.setFont(font);
        surnameLabel.setFont(font);
        testLabel.setFont(font);
        testResultLabel.setFont(font);

        setIN.setFont(font2);
        setName.setFont(font2);
        setSurname.setFont(font2);
        setTest.setFont(font2);
        setTestResult.setFont(font2);

        okButton = new JButton("OK");
        okButton.addActionListener(new MouseAction());

        new InfoBuilder.Builder().gridX(0).gridY(0).top(10).right(20).builder(secondPanel, INLabel, spgbc);
        new InfoBuilder.Builder().gridX(1).gridY(0).top(10).builder(secondPanel, setIN, spgbc);
        new InfoBuilder.Builder().gridX(0).gridY(1).top(10).right(20).builder(secondPanel, nameLabel, spgbc);
        new InfoBuilder.Builder().gridX(1).gridY(1).top(10).builder(secondPanel, setName, spgbc);
        new InfoBuilder.Builder().gridX(0).gridY(2).top(10).right(20).builder(secondPanel, surnameLabel, spgbc);
        new InfoBuilder.Builder().gridX(1).gridY(2).top(10).builder(secondPanel, setSurname, spgbc);
        new InfoBuilder.Builder().gridX(0).gridY(3).top(10).right(20).builder(secondPanel, testLabel, spgbc);
        new InfoBuilder.Builder().gridX(1).gridY(3).top(10).builder(secondPanel, setTest, spgbc);

        new InfoBuilder.Builder().gridX(0).gridY(4).top(10).right(10).builder(secondPanel, testResultLabel, spgbc);
        new InfoBuilder.Builder().gridX(1).gridY(4).top(10).builder(secondPanel, setTestResult, spgbc);
        new InfoBuilder.Builder().gridX(1).gridY(5).top(10).builder(secondPanel, okButton, spgbc);

        frame.setVisible(true);
        setSEPanel();
    }

    private void setSEPanel(){
        sEPanel = new JPanel(new GridBagLayout());
        frame.add(sEPanel);
        sEPanel.setBounds(215, 265, 500, 170);
        sEPanel.setBackground(Color.LIGHT_GRAY);
        frame.setVisible(true);
    }

    private void buttonOn(){
        String getIN = INField.getText().trim();

        if(getIN.equals("")){
            JOptionPane.showMessageDialog(frame, "You must enter the patient's identification number \nto be able to see the wish test.");
        }
        else{
            String getReturnValues;

            TestCommandFile tcf = new TestCommandFile();
            WishTestOperations wto = new WishTestOperations();

            tcf.setCommand(new SeeWishTest(wto));
            getReturnValues = tcf.executeOperation(getIN);

            if(getReturnValues == null)
                JOptionPane.showMessageDialog(frame, "Wrong identification number. Please check it again.");
            else{
                clickCount = 1;
                panel.setVisible(false);
                emptyPanel.setVisible(false);

                String[] values = getReturnValues.split("@", 5);
                this.IN = values[0];
                this.name = values[1];
                this.surname = values[2];
                this.testName = values[3];
                this.testResult = values[4];

                setSecondPanel();
            }
        }
    }

    private class MouseAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if(clickCount == 0){
                buttonOn();
            }
            else{
                clickCount = 0;
                secondPanel.setVisible(false);
                sEPanel.setVisible(false);

                titlePanel.setVisible(false);
                initialize();
            }
        }
    }
}