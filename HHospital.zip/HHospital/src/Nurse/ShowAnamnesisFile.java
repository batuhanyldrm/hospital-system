package Nurse;

import java.io.File;
import java.util.Scanner;

public class ShowAnamnesisFile {
    private String name, surname, gender, pIllnesses, tMedications, diagnosis, phoneNumber, stringIN, age;
    private long IN, tempIN;
    private int count = 0;

    public ShowAnamnesisFile(long IN){
        this.IN = IN;
    }

    public String returnInfo(){
        File file = new File(System.getProperty("user.dir") + "/patient_anamnesis/patient_ins.txt");
        File INFile;
        
        if(!file.exists())
            return null;

        try{
            //Search the IN in the general file.
            Scanner scanFirst = new Scanner(file);
            while(scanFirst.hasNextLong()){
                tempIN = scanFirst.nextLong();

                if(IN == tempIN){
                    count = 1;
                    break;
                }
            }
            scanFirst.close();

            if(count == 1){
                //If found, than get result from IN file.
                INFile = new File(System.getProperty("user.dir") + "/patient_anamnesis/" + IN + ".txt");
                Scanner scan = new Scanner(INFile);

                stringIN = scan.next();
                scan.nextLine();

                name = scan.nextLine();
                surname = scan.next();
                age = scan.next();
                phoneNumber = scan.next();
                gender = scan.next();
                scan.nextLine();

                pIllnesses = scan.nextLine();
                tMedications = scan.nextLine();
                diagnosis = scan.nextLine();
                scan.nextLine();

                scan.close();
                return IN + "@" + name + "@" + surname + "@" + age + "@" + phoneNumber + "@" + gender + "@" +
                        pIllnesses + "@" + tMedications + "@" + diagnosis;
            }
            else if(count == 0){
                return null;
            }
        }
        catch(Exception e){

        }
        return null;
    }
}