package Nurse;

public abstract class FileStrategy {
    public String patient(int IN){
        return null;
    }
}