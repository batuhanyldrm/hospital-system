package Manager;

public class Main {
	public Main() {
		AdminDashboard adminDashboard = new AdminDashboard();
		adminDashboard.setVisible(true);
	}
}
