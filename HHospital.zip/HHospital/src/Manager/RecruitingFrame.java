package Manager;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;

public class RecruitingFrame extends JFrame {

	private JPanel contentPane;
	private JTextField tfTC;
	private JTextField tfName;
	private JTextField tfSurname;
	private JTextField tfPhone;
	private ButtonGroup bg;
	private EmployeeFactory employeeFactory;
	private int[] monthDays = new int[12];
	private JTextField tfAnswer;
	private JTextField tfPassword;
	
	
	public RecruitingFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 561, 412);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		bg = new ButtonGroup();
		employeeFactory = new EmployeeFactory();
		monthDays[0] = 31;
		monthDays[1] = 29;
		monthDays[2] = 31;
		monthDays[3] = 30;
		monthDays[4] = 31;
		monthDays[5] = 30;
		monthDays[6] = 31;
		monthDays[7] = 31;
		monthDays[8] = 30;
		monthDays[9] = 31;
		monthDays[10] = 30;
		monthDays[11] = 31;
		
		JLabel lblTC = new JLabel("TC:");
		lblTC.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTC.setBounds(27, 85, 46, 14);
		contentPane.add(lblTC);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblName.setBounds(27, 108, 46, 14);
		contentPane.add(lblName);
		
		JLabel lblSurname = new JLabel("Surname:");
		lblSurname.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSurname.setBounds(27, 133, 60, 14);
		contentPane.add(lblSurname);
		
		JLabel lblBirthDate = new JLabel("Birth Date(MM/DD/YYYY):");
		lblBirthDate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblBirthDate.setBounds(27, 158, 158, 14);
		contentPane.add(lblBirthDate);
		
		JLabel lblGender = new JLabel("Gender:");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGender.setBounds(27, 183, 60, 14);
		contentPane.add(lblGender);
		
		JLabel lblPhone = new JLabel("Phone:");
		lblPhone.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPhone.setBounds(27, 208, 73, 14);
		contentPane.add(lblPhone);
		
		JLabel lblJobTitle = new JLabel("Job Title:");
		lblJobTitle.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblJobTitle.setBounds(27, 233, 64, 14);
		contentPane.add(lblJobTitle);
		
		JLabel lblQuestion = new JLabel("Question:");
		lblQuestion.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblQuestion.setBounds(27, 258, 99, 14);
		contentPane.add(lblQuestion);
		
		tfTC = new JTextField();
		tfTC.setBounds(194, 84, 278, 20);
		contentPane.add(tfTC);
		tfTC.setColumns(10);
		
		tfName = new JTextField();
		tfName.setColumns(10);
		tfName.setBounds(194, 107, 278, 20);
		contentPane.add(tfName);
		
		tfSurname = new JTextField();
		tfSurname.setColumns(10);
		tfSurname.setBounds(194, 131, 278, 20);
		contentPane.add(tfSurname);
		
		tfPhone = new JTextField();
		tfPhone.setColumns(10);
		tfPhone.setBounds(194, 208, 278, 20);
		contentPane.add(tfPhone);
		
		JRadioButton rbMale = new JRadioButton("Male");
		rbMale.setBounds(224, 181, 109, 23);
		contentPane.add(rbMale);
		
		JRadioButton rbFemale = new JRadioButton("Female");
		rbFemale.setBounds(351, 181, 93, 23);
		contentPane.add(rbFemale);
		
		bg.add(rbMale);
		bg.add(rbFemale);
		
		JComboBox cbJobTitle = new JComboBox();
		cbJobTitle.setModel(new DefaultComboBoxModel(new String[] {"Doctor", "Nurse", "Secretary"}));
		cbJobTitle.setSelectedItem(null);
		cbJobTitle.setBounds(194, 231, 278, 22);
		contentPane.add(cbJobTitle);
		
		JComboBox cbDepartment = new JComboBox();
		cbDepartment.setModel(new DefaultComboBoxModel(new String[] {"What was your childhood nickname?" , "What is the name of your childhood friend?" , "What was your dream job as a child?" , "Who was your childhood hero?" , "In what city and country do you want to retire?"}));
		cbDepartment.setSelectedItem(null);
		cbDepartment.setBounds(194, 256, 278, 22);
		contentPane.add(cbDepartment);
		
		JComboBox cbDate = new JComboBox();
		cbDate.setModel(new DefaultComboBoxModel(new String[] {"1" , "2" , "3" , "4" , "5" , "6" , "7" , "8" , "9" , "10" , "11" , "12" , "13" , "14" , "15" , "16" , "17" , "18" , "19" , "20" , "21" , "22" , "23" , "24" , "25" , "26" , "27" , "28" , "29" , "30" , "31"}));
		cbDate.setSelectedItem(null);
		cbDate.setBounds(195, 156, 60, 22);
		contentPane.add(cbDate);
		
		JComboBox cbMonth = new JComboBox();
		cbMonth.setModel(new DefaultComboBoxModel(new String[] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		cbMonth.setSelectedItem(null);
		cbMonth.setBounds(265, 156, 108, 22);
		contentPane.add(cbMonth);
	
		JComboBox cbYear = new JComboBox();
		cbYear.setModel(new DefaultComboBoxModel(new String[] 
				{"1923" , "1924" , "1925" , "1926" , "1927" , "1928" , "1929" , "1930" , "1931" , "1932" , "1933" , "1934" , "1935" , "1936" , "1937" , "1938" , "1939" , "1940" , "1941" , "1942" , "1943" , "1944"
				, "1945" , "1946" , "1947" , "1948" , "1949" , "1950" , "1951" , "1952" , "1953" , "1954" , "1955" , "1956" , "1957" , "1958" , "1959" , "1960" , "1961" , "1962" , "1963" , "1964" , "1965" , "1966" , "1967" , "1968" , "1969"
				, "1970" , "1971" , "1972" , "1973" , "1974" , "1975" , "1976" , "1977" , "1978" , "1979" , "1980" , "1981" , "1982" , "1983" , "1984" , "1985" , "1986" , "1987" , "1988" , "1989" , "1990" , "1991" , "1992"
				, "1993" , "1994" , "1995" , "1996" , "1997" , "1998" , "1999" , "2000" , "2001" , "2002" , "2003" , "2004" , "2005" , "2006" , "2007" , "2008" , "2009" , "2010" , "2011" , "2012" , "2013" , "2014" , "2015"
				, "2016" , "2017" , "2018" , "2019" , "2020" , "2021"} ));
		
		cbYear.setSelectedItem(null);
		cbYear.setBounds(379, 156, 89, 22); 
		contentPane.add(cbYear);
		
		JButton btnSave = new JButton("Save");
		btnSave.setForeground(Color.WHITE);
		btnSave.setBackground(Color.GRAY);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//String  
				if(cbDate.getSelectedItem() == null || cbMonth.getSelectedItem() == null ||cbYear.getSelectedItem() == null){
					JOptionPane.showMessageDialog(null, "message");
				}

				else if(cbJobTitle.getSelectedItem().equals("Doctor")) {
					Doctor doctor = (Doctor)employeeFactory.getEmployee("DOCTOR");

					doctor.setTc(tfTC.getText());
					doctor.setName(tfName.getText());
					doctor.setSurname(tfSurname.getText());
					String birthDateString = (String)cbMonth.getSelectedItem() + "/" + cbDate.getSelectedItem() + "/" + cbYear.getSelectedItem();
					doctor.setBirthDate(birthDateString);

					if(rbMale.isSelected()) {
						doctor.setGender("Male");
					}
					else if (rbFemale.isSelected()) {
						doctor.setGender("Female");
					}
					else if(doctor.getTc().equals("") || doctor.getName().equals("") || doctor.getSurname().equals("") || doctor.getBirthDate().equals("") || doctor.getGender().equals("") || doctor.getPhone().equals("") || doctor.getJobTitle().equals("") || doctor.getDepartment().equals("")) {
						JOptionPane.showMessageDialog(null, "Fill all fields!");
					return;
					}
					else if(!rbMale.isSelected() || !rbFemale.isSelected()){
						JOptionPane.showMessageDialog(null, "Please select gender!");
						return;
					}
					else
						return;
					doctor.setPhone(tfPhone.getText());
					doctor.setDepartment((String)cbDepartment.getSelectedItem());
					doctor.setAnswer(tfAnswer.getText());
					doctor.setPassword(tfPassword.getText());
					
					try(BufferedWriter writer = new BufferedWriter(new FileWriter("doctorFile.txt", true))){  
						//writer.write(doctor.toString());
						writer.write(doctor.getTc() + '\n');
						writer.write(doctor.getName() + '\n');
						writer.write(doctor.getSurname() + '\n');
						
						writer.write(doctor.getPassword() + "\n");
						writer.write(doctor.getBirthDate() + '\n');
						writer.write(doctor.getGender() + '\n');
						writer.write(doctor.getPhone() + '\n');
						writer.write(doctor.getAnswer() + '\n');
						writer.write('\n');

						JOptionPane.showMessageDialog(null, "Employee registered !");
						tfTC.setText(null);
						tfName.setText(null);
						tfSurname.setText(null);
						tfPhone.setText(null);
						cbDate.setSelectedItem(null);
						cbMonth.setSelectedItem(null);
						cbYear.setSelectedItem(null);
						rbMale.setSelectedIcon(null);
						rbFemale.setSelectedIcon(null);
						cbJobTitle.setSelectedItem(null);
						cbDepartment.setSelectedItem(null);
						tfAnswer.setText(null);
						cbDepartment.setSelectedItem(null);
						tfPassword.setText(null);
					}
			        catch(IOException e) {
			            System.out.println("Error occurred while writing the informations!");
					}
					
					/*try(BufferedWriter writer = new BufferedWriter(new FileWriter("doctorstemp.txt", true))){
			           writer.write(doctor.toString()+'\n');
					}
			        catch(IOException e) {
			            System.out.println("Error occurred while writing the informations!");
			        }*/
				}

				else if(cbJobTitle.getSelectedItem().equals("Secretary")) {
					Secretary secretary = (Secretary)employeeFactory.getEmployee("SECRETARY");

					secretary.setTc(tfTC.getText());
					secretary.setName(tfName.getText());
					secretary.setSurname(tfSurname.getText());
					String birthDateString = (String)cbMonth.getSelectedItem() + "/" + cbDate.getSelectedItem() + "/" + cbYear.getSelectedItem();
					secretary.setBirthDate(birthDateString);

					if(rbMale.isSelected()) {
						secretary.setGender("Male");
					}
					else if (rbFemale.isSelected()) {
						secretary.setGender("Female");
					}
					else if(secretary.getTc().equals("") || secretary.getName().equals("") || secretary.getSurname().equals("") || secretary.getBirthDate().equals("") || secretary.getGender().equals("") || secretary.getPhone().equals("") || secretary.getJobTitle().equals("") || secretary.getDepartment().equals("")) {
						JOptionPane.showMessageDialog(null, "Fill all fields!");
					return;
					}
					else if(!rbMale.isSelected() || !rbFemale.isSelected()){
						JOptionPane.showMessageDialog(null, "Please select gender!");
						return;
					}
					else {
						return;
					}
					secretary.setPhone(tfPhone.getText());
					secretary.setDepartment((String)cbDepartment.getSelectedItem());
					secretary.setJobTitle((String)cbJobTitle.getSelectedItem());
					secretary.setAnswer(tfAnswer.getText());
					secretary.setPassword(tfPassword.getText());
					
					try(BufferedWriter writer = new BufferedWriter(new FileWriter("secretaryFile.txt", true))){  
						//writer.write(secretary.toString());   
						writer.write(secretary.getTc() + '\n');
						writer.write(secretary.getName() + '\n');
						writer.write(secretary.getSurname() + '\n');
						writer.write(secretary.getPassword() + "\n");

						writer.write(secretary.getBirthDate() + '\n');
						writer.write(secretary.getGender() + '\n');
						writer.write(secretary.getPhone() + '\n');
						writer.write(secretary.getAnswer() + "\n");
						writer.write('\n');
			            JOptionPane.showMessageDialog(null, "Employee succesfully registered.");
			        	
			            tfTC.setText(null);
						tfName.setText(null);
						tfSurname.setText(null);
						tfPhone.setText(null);
						cbDate.setSelectedItem(null);
						cbMonth.setSelectedItem(null);
						cbYear.setSelectedItem(null);
						tfAnswer.setText(null);
						cbDepartment.setSelectedItem(null);
						cbJobTitle.setSelectedItem(null);
						tfPassword.setText(null);
					}
			        catch(IOException e) {
			            System.out.println("Error occurred while writing the informations!");
					}
					
					/*try(BufferedWriter writer = new BufferedWriter(new FileWriter("secretariestemp.txt", true))){
						writer.write(secretary.toString());   
			        }
			        catch(IOException e) {
			            System.out.println("Error occurred while writing the informations!");
			        }*/
				}

				else if(cbJobTitle.getSelectedItem().equals("Nurse")) {
					Nurse nurse = (Nurse)employeeFactory.getEmployee("NURSE");

					nurse.setTc(tfTC.getText());
					nurse.setName(tfName.getText());
					nurse.setSurname(tfSurname.getText());
					String birthDateString = (String)cbMonth.getSelectedItem() + "/" + cbDate.getSelectedItem() + "/" + cbYear.getSelectedItem();
					nurse.setBirthDate(birthDateString);

					if(rbMale.isSelected()) {
						nurse.setGender("Male");
					}
					else if (rbFemale.isSelected()) {
						nurse.setGender("Female");
					}
					else if(nurse.getTc().equals("") && nurse.getName().equals("") && nurse.getSurname().equals("") && nurse.getBirthDate().equals("") && nurse.getGender().equals("") && nurse.getPhone().equals(null) && nurse.getJobTitle().equals("") && nurse.getDepartment().equals("")) {
						JOptionPane.showMessageDialog(null, "Fill all fields!");
					return;
					}
					else if(!rbMale.isSelected() || !rbFemale.isSelected()){
						JOptionPane.showMessageDialog(null, "Please select gender!");
						return;
					}
					else {
						return;
					}
					nurse.setPhone(tfPhone.getText());
					nurse.setDepartment((String)cbDepartment.getSelectedItem());
					nurse.setJobTitle((String)cbJobTitle.getSelectedItem());
					nurse.setAnswer(tfAnswer.getText());
					nurse.setPassword(tfPassword.getText());

					try(BufferedWriter writer = new BufferedWriter(new FileWriter("nurseFile.txt", true))){		            
							//writer.write(nurse.toString());   
							writer.write(nurse.getTc() + '\n');
							writer.write(nurse.getName() + '\n');
							writer.write(nurse.getSurname() + '\n');
							writer.write(nurse.getPassword() + "\n");

							writer.write(nurse.getBirthDate() + '\n');
							writer.write(nurse.getGender() + '\n');
							writer.write(nurse.getPhone() + '\n');
							writer.write(nurse.getAnswer() + "\n");
							writer.write('\n');
			            JOptionPane.showMessageDialog(null, "Employee succesfully registered.");
			        	
			            tfTC.setText(null);
						tfName.setText(null);
						tfSurname.setText(null);
						tfPhone.setText(null);
						cbDate.setSelectedItem(null);
						cbMonth.setSelectedItem(null);
						cbYear.setSelectedItem(null);
						cbDepartment.setSelectedItem(null);
						tfAnswer.setText(null);
						cbJobTitle.setSelectedItem(null);
						tfPassword.setText(null);
					}
			        catch(IOException e) {
			            System.out.println("Error occurred while writing the informations!");
					}
					
					/*try(BufferedWriter writer = new BufferedWriter(new FileWriter("nursestemp.txt", true))){
						writer.write(nurse.toString());   
			        }
			        catch(IOException e) {
         
			            System.out.println("Error occurred while writing the informations!");
			        }*/
				}

				else if(cbJobTitle.getSelectedItem().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Select Job Title!");
					return;
				}
			}
		});

		btnSave.setBounds(383, 331, 89, 42);
		contentPane.add(btnSave);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(Color.WHITE);
		btnBack.setBackground(Color.GRAY);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 AdminDashboard adminDashboard = new AdminDashboard();
				 adminDashboard.setVisible(true);
				 setVisible(false);
			}
		});
		btnBack.setBounds(194, 331, 89, 42);
		contentPane.add(btnBack);
		
		tfAnswer = new JTextField();
		tfAnswer.setColumns(10);
		tfAnswer.setBounds(194, 282, 278, 20);
		contentPane.add(tfAnswer);
		
		JLabel lblAnswer = new JLabel("Answer:");
		lblAnswer.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblAnswer.setBounds(27, 283, 99, 14);
		contentPane.add(lblAnswer);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPassword.setBounds(27, 308, 99, 14);
		contentPane.add(lblPassword);
		
		tfPassword = new JTextField();
		tfPassword.setColumns(10);
		tfPassword.setBounds(194, 307, 278, 20);
		contentPane.add(tfPassword);
	}
}
