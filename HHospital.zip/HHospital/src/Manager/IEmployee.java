package Manager;

public interface IEmployee {
	String toString();
}
