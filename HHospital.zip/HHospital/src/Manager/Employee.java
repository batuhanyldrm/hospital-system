package Manager;

public class Employee implements IEmployee {
	//private int id;
	private String tc;
	private String name;
	private String surname;
	private String birthDate;
	private String gender;
	private String phone;
	private String jobTitle;
	private String department;
	private String answer;
	private String password;
	
	public Employee(String tc, String name, String surname,String birthDate, String gender, String phone, String jobTitle, String department, String answer, String password) {
		//this.id = 1 + (int)(Math.random()* 9999);
		this.tc = tc;
		this.name = name;
		this.surname = surname;
		this.birthDate = birthDate;
		this.gender = gender;
		this.phone = phone;
		this.jobTitle = jobTitle;
		this.department = department;
		this.answer = answer;
		this.password = password;
	}
	
	public Employee() {
		//this.id = 1 + (int)(Math.random()* 9999);
		this.tc = "00000000000";
		this.name = "Default Name";
		this.surname = "Default Surname";
		this.birthDate = "01/01/1970";
		this.gender = "Default Gender";
		this.phone = "000000000";
		this.jobTitle = "Default Title";
		this.department = "Default Question";
		this.answer = "Default Answer";
		this.password = "000000";
	}
	
/*	public int getId() {
		return this.id;
	}*/

	public String getTc() {
		return tc;
	}

	public void setTc(String tc) {
		this.tc = tc;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String toString() {
		return /*this.id + " " +*/ this.tc + "\n" + this.name + "\n" + this.surname + "\n" + this.birthDate + "\n" + this.gender + "\n" + this.phone + "\n" + this.department + "\n" + this.answer + "\n" + this.password + "\n";
	}
}
