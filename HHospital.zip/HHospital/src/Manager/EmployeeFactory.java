package Manager;

public class EmployeeFactory {
	
	public IEmployee getEmployee(String employeeType) {
		if(employeeType == null) {
			return null;
		}
		if(employeeType.equalsIgnoreCase("DOCTOR")) {
			return new Doctor();
		}
		else if(employeeType.equalsIgnoreCase("NURSE")) {
			return new Nurse();
		}
		else if(employeeType.equalsIgnoreCase("SECRETARY")) {
			return new Secretary();
		}
		return null;
	}
}
