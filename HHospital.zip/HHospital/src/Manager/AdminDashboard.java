package Manager;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;

public class AdminDashboard extends JFrame {

	private JPanel contentPane;

	public AdminDashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 526);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		

		JList list = new JList();
		list.setBounds(10, 124, 684, 275);
		contentPane.add(list);
		list.setVisible(false);
		
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			list.setVisible(false);
			btnNewButton.setVisible(false);

			}
		});
		btnNewButton.setBounds(513, 410, 115, 41);
		contentPane.add(btnNewButton);
		btnNewButton.setVisible(false);
		
		JButton btnRecruiting = new JButton("Recruiting");
		btnRecruiting.setBackground(Color.GRAY);
		btnRecruiting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				RecruitingFrame recruitingFrame = new RecruitingFrame();
				recruitingFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnRecruiting.setBounds(56, 70, 110, 49);
		contentPane.add(btnRecruiting);
		
		JButton btnDismissal = new JButton("Dismissal");
		btnDismissal.setBackground(Color.GRAY);
		btnDismissal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String IN, name, surname, password, birthDate, gender, phoneNumber, secAns;

				list.setVisible(false);
				String option = JOptionPane.showInputDialog("Please enter option!(1-Doctor,2-Secretary,3-Nurse)");

				if(option.equals("1")) {
					String doctorTC = JOptionPane.showInputDialog("Please enter TC!");
					
					try{
						File file = new File("doctorFile.txt");
						File tempFile = new File("tempDoctorFile.txt");

						Scanner scan = new Scanner(file);
						BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile, true));
						
						while(scan.hasNextLine()){
							IN = scan.next();
							scan.nextLine();

							name = scan.nextLine();
							surname = scan.next();
							password = scan.next();

							birthDate = scan.next();
							gender = scan.next();
							phoneNumber = scan.next();

							scan.nextLine();
							secAns = scan.nextLine();
							scan.nextLine();

							if(!doctorTC.equals(IN)){
								bw.write(IN + "\n" + name + "\n" + surname + "\n" + password + "\n" + birthDate + "\n" + gender + "\n");
								bw.write(phoneNumber + "\n" + secAns + "\n\n");
							}
							else
								JOptionPane.showMessageDialog(null, "Deleted successfully.");
						}

						scan.close();
						bw.close();
						file.delete();
						tempFile.renameTo(file);
					}
					catch(Exception a){
						a.printStackTrace();
					}
					
					/*if(isIDexist(doctorTC, option)) {
						ArrayList<String> doctorlines = new ArrayList<String>();
						try(Scanner scanner = new Scanner(new BufferedReader(new FileReader("doctors.txt")))){
							while(scanner.hasNextLine()) {
								String doctor_info = scanner.nextLine();

								if(doctor_info.contains(doctorTC)) {
									continue;
								}

								doctorlines.add(doctor_info);
							}
						}
						catch(FileNotFoundException x) {
							System.out.println("Dosya Bulunamad�...");
						}
						catch(IOException x) {
							
							System.out.println("Dosya a��l�rken bir hata olu�tu....");
						}

						try(BufferedWriter writer = new BufferedWriter(new FileWriter("doctorstemp.txt", false))){
							for(String line: doctorlines) {
								writer.write(line+"\n");
								
							}
							
						}
						catch(IOException a) {
							
							System.out.println("Dosya a��l�rken hata olu�tu...");
						}
					}*/
				}
				else if(option.equals("2")) {
					String secretaryTC = JOptionPane.showInputDialog("Please enter TC!");
					
					try{
						File file = new File("secretaryFile.txt");
						File tempFile = new File("tempSecretaryFile.txt");

						Scanner scan = new Scanner(file);
						BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile, true));
						
						while(scan.hasNextLine()){
							IN = scan.next();
							scan.nextLine();

							name = scan.nextLine();
							surname = scan.next();
							password = scan.next();

							birthDate = scan.next();
							gender = scan.next();
							phoneNumber = scan.next();

							scan.nextLine();
							secAns = scan.nextLine();
							scan.nextLine();

							if(!secretaryTC.equals(IN)){
								bw.write(IN + "\n" + name + "\n" + surname + "\n" + password + "\n" + birthDate + "\n" + gender + "\n");
								bw.write(phoneNumber + "\n" + secAns + "\n\n");
							}
							else
								JOptionPane.showMessageDialog(null, "Deleted successfully.");
						}

						scan.close();
						bw.close();
						file.delete();
						tempFile.renameTo(file);
					}
					catch(Exception a){
						a.printStackTrace();
					}
				}
				else if(option.equals("3")) {
					String nurseTC = JOptionPane.showInputDialog("Please enter TC!");
					
					try{
						File file = new File("nurseFile.txt");
						File tempFile = new File("tempNurseFile.txt");

						Scanner scan = new Scanner(file);
						BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile, true));
						
						while(scan.hasNextLine()){
							IN = scan.next();
							scan.nextLine();

							name = scan.nextLine();
							surname = scan.next();
							password = scan.next();

							birthDate = scan.next();
							gender = scan.next();
							phoneNumber = scan.next();

							scan.nextLine();
							secAns = scan.nextLine();
							scan.nextLine();

							if(!nurseTC.equals(IN)){
								bw.write(IN + "\n" + name + "\n" + surname + "\n" + password + "\n" + birthDate + "\n" + gender + "\n");
								bw.write(phoneNumber + "\n" + secAns + "\n\n");
							}
							else
								JOptionPane.showMessageDialog(null, "Deleted successfully.");
						}

						scan.close();
						bw.close();
						file.delete();
						tempFile.renameTo(file);
					}
					catch(Exception a){
						a.printStackTrace();
					}
				}
				else{
					btnNewButton.setVisible(false);
				    list.setVisible(false);
				    JOptionPane.showMessageDialog(null, "Please enter a valid transaction!");
			}
			}});
		btnDismissal.setBounds(218, 70, 110, 49);
		contentPane.add(btnDismissal);
		
		JLabel lblTitle = new JLabel("Hospital");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTitle.setBounds(317, 11, 92, 22);
		contentPane.add(lblTitle);
		
	
		JButton btnEmployeeList = new JButton("Employee List");
		btnEmployeeList.setBackground(Color.GRAY);
		btnEmployeeList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String compose;
				String IN, name, surname, password, birthDate, gender, phoneNumber, secAns;

				String option = JOptionPane.showInputDialog("Please enter which list you want to see!(1-Doctor List,2-Secretary List,3-Nurse List)");
				list.setVisible(false);
				btnNewButton.setVisible(true);
				
				if(option.equals("1")) {
					list.setVisible(true);
					try {
						DefaultListModel<String> DLM = new DefaultListModel<String>();

						File file = new File("doctorFile.txt");
						Scanner scan = new Scanner(file);

						while(scan.hasNextLine()){
							IN = scan.next();
							scan.nextLine();

							name = scan.nextLine();
							surname = scan.next();
							password = scan.next();

							birthDate = scan.next();
							gender = scan.next();
							phoneNumber = scan.next();

							scan.nextLine();
							secAns = scan.nextLine();
							scan.nextLine();

							compose = IN + ", " + name + ", " + surname + ", " + password + ", " + birthDate + ", " + gender + ", " + phoneNumber + ", " + secAns;
							DLM.addElement(compose);
						}
						list.setModel(DLM);
						scan.close();
						/*File tempFile = new File("doctorstemp.txt");
						Scanner tempScanner = new Scanner(new BufferedReader(new FileReader(tempFile)));
						ArrayList<String> showList = new ArrayList<String>();
						DefaultListModel<String> DLM = new DefaultListModel<String>();
						
						while(tempScanner.hasNextLine()) {
							
							showList.add(tempScanner.nextLine());
						}
						tempScanner.close();
						
						for(String doctors : showList) {
							System.out.println(doctors);
							DLM.addElement(doctors);
						}
					
						list.setModel(DLM);*/
					}
					catch (IOException c) {
						JOptionPane.showMessageDialog(null, "File not found!");
					}
				}
			
				else if(option.equals("2")) {
					list.setVisible(true);
					try {
						DefaultListModel<String> DLM = new DefaultListModel<String>();

						File file = new File("secretaryFile.txt");
						Scanner scan = new Scanner(file);

						while(scan.hasNextLine()){
							IN = scan.next();
							scan.nextLine();

							name = scan.nextLine();
							surname = scan.next();
							password = scan.next();

							birthDate = scan.next();
							gender = scan.next();
							phoneNumber = scan.next();

							scan.nextLine();
							secAns = scan.nextLine();
							scan.nextLine();

							compose = IN + ", " + name + ", " + surname + ", " + password + ", " + birthDate + ", " + gender + ", " + phoneNumber + ", " + secAns;
							DLM.addElement(compose);
						}
						list.setModel(DLM);
					}
					catch (IOException c) {
						JOptionPane.showMessageDialog(null, "File not found!");
					}
				}
				else if(option.equals("3")) {
					list.setVisible(true);
					try {
						DefaultListModel<String> DLM = new DefaultListModel<String>();

						File file = new File("nurseFile.txt");
						Scanner scan = new Scanner(file);

						while(scan.hasNextLine()){
							IN = scan.next();
							scan.nextLine();

							name = scan.nextLine();
							surname = scan.next();
							password = scan.next();

							birthDate = scan.next();
							gender = scan.next();
							phoneNumber = scan.next();

							scan.nextLine();
							secAns = scan.nextLine();
							scan.nextLine();

							compose = IN + ", " + name + ", " + surname + ", " + password + ", " + birthDate + ", " + gender + ", " + phoneNumber + ", " + secAns;
							DLM.addElement(compose);
						}
						list.setModel(DLM);
					}
					catch (IOException c) {
						JOptionPane.showMessageDialog(null, "File not found!");
					}
				}
				
				else {
						btnNewButton.setVisible(false);
					    list.setVisible(false);
					    JOptionPane.showMessageDialog(null, "Please enter a valid transaction!");
				}
			}
			});	
		
		btnEmployeeList.setBounds(383, 70, 110, 49);
		contentPane.add(btnEmployeeList);
		
		JButton btnAccounting = new JButton("Accounting");
		btnAccounting.setBackground(Color.GRAY);
		btnAccounting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list.setVisible(true);
				btnNewButton.setVisible(true);

				try {
					File tempFile = new File("accounting.txt");
					Scanner tempScanner = new Scanner(new BufferedReader(new FileReader(tempFile)));
					ArrayList<String> accountingList = new ArrayList<String>();
					DefaultListModel<String> DLM = new DefaultListModel<String>();
					
					while(tempScanner.hasNextLine()) {
						
						accountingList.add(tempScanner.nextLine());
					}
					tempScanner.close();
					
					for(String Accounting : accountingList) {
						System.out.println(Accounting);
						DLM.addElement(Accounting);
					}
				
					list.setModel(DLM);
					
				
					
				}
				catch (IOException c) {
					JOptionPane.showMessageDialog(null, "File not found!");
				}
				
				
				}});
		
		btnAccounting.setBounds(547, 70, 110, 49);
		contentPane.add(btnAccounting);

	}
		public boolean isIDexist(String ID,String option){
			if(option.equals("1")) {
	
				try(Scanner scanner = new Scanner(new BufferedReader(new FileReader("doctorFile.txt")))){
		            
		            while(scanner.hasNextLine()) {
		                
		                String doctor_info = scanner.nextLine();
		                
		                String[] array = doctor_info.split(" ");
		                
		                if(array[0].equals(ID)) {                 
		                   
		                	return true;
		                }
		               
		            }
		            return false;
				}
		        catch(Exception e) {
		            System.out.println("Dosya Bulunamad�...");
		            return false;
		        }
		        /*catch(IOException e) {
		            System.out.println("Dosya a��l�rken bir hata olu�tu....");
		            return false;
				}*/
			}

			if(option.equals("2")) {
				try(Scanner scanner = new Scanner(new BufferedReader(new FileReader("secretaryFile.txt")))){

		            while(scanner.hasNextLine()) {
		                
		                String secretaries_info = scanner.nextLine();
		                
		                String[] array = secretaries_info.split(" ");
		                
		                if(array[0].equals(ID)) {                 
		                   
		                	return true;
		                }
		            }
		            return false;
				}
		        catch(Exception e) {
		            System.out.println("Dosya Bulunamad�...");
		            return false;
		        }
		        /*catch(IOException e) {
		            System.out.println("Dosya a��l�rken bir hata olu�tu....");
		            return false;
				}*/
			}
			
			if(option.equals("3")) {
				try(Scanner scanner = new Scanner(new BufferedReader(new FileReader("nurseFile.txt")))){
		            
		            while(scanner.hasNextLine()) {
		                
		                String nurses_info = scanner.nextLine();
		                
		                String[] array = nurses_info.split(" ");
		                
		                if(array[0].equals(ID)) {
		                	return true;
		                }
		            }
		            return false;
				}
		        catch(Exception e) {
		            System.out.println("Dosya Bulunamad�...");
		            return false;
				}
			
			/*catch(IOException e) {
				System.out.println("Dosya a��l�rken bir hata olu�tu....");
				return false;
			}*/
		}
		
		else {
			return false;
		}
	}
}