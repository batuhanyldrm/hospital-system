package Manager;

public class Secretary extends Employee {

	public Secretary(String tc, String name, String surname, String birthDate, String gender, String phone, String jobTitle, String department, String answer, String password) {
		super(tc, name, surname, birthDate, gender, phone, jobTitle, department, answer, password);
	}
	
	public Secretary() {}
}
