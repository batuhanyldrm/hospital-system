package OOPDoctor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class WishTest extends JFrame implements Decorator{
	private JTextField tfTC;
	private JTextField tfname;
	private JTextField tfsurname;
	private JTextField tfwishlist;
	
	private JPanel panel;
	
	public WishTest() {
		setTitle("Wish Test");
		setSize(500,400);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		JLabel lblwtest = new JLabel("Wish Test");
		lblwtest.setFont(new Font("Dialog", Font.BOLD, 20));
		lblwtest.setBounds(193, 15, 150, 20);
		panel.add(lblwtest);
		
		tfTC = new JTextField(11);
		tfTC.setBounds(250, 60, 150, 20);
		JLabel lbltc = new JLabel("TC :");
		lbltc.setFont(new Font("Dialog", Font.BOLD, 15));
		lbltc.setBounds(125, 50, 40, 40);
		panel.add(lbltc);
		panel.add(tfTC);
		
		tfname = new JTextField(20);
		tfname.setBounds(250, 100, 150, 20);
		JLabel lblname = new JLabel("Name :");
		lblname.setFont(new Font("Dialog", Font.BOLD, 15));
		lblname.setBounds(125, 100, 100, 20);
		panel.add(lblname);
		panel.add(tfname);
		
		tfsurname = new JTextField(20);
		tfsurname.setBounds(250, 140, 150, 20);
		JLabel lblsurname = new JLabel("Surname :");
		lblsurname.setFont(new Font("Dialog", Font.BOLD, 15));
		lblsurname.setBounds(125, 140, 160, 20);
		panel.add(lblsurname);
		panel.add(tfsurname);
		
		tfwishlist = new JTextField(50);
		tfwishlist.setBounds(250, 180, 150, 20);
		JLabel lblwishtest = new JLabel("Wish Test :");
		lblwishtest.setFont(new Font("Dialog", Font.BOLD, 15));
		lblwishtest.setBounds(125, 180, 160, 20);
		panel.add(lblwishtest);
		panel.add(tfwishlist);
		
		JButton btnsave = new JButton("Save");
		btnsave.setBounds(160, 220, 65, 25);
		btnsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Save();
					
			}
		});
		JButton btnback = new JButton("Back");
		btnback.setBounds(280, 220, 65, 25);
		panel.add(btnback);
		
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//MainPage mainpage = new MainPage();
				
				setVisible(false);
				//mainpage.setVisible(true);				
			}
		});
		
		panel.add(btnsave);
		add(panel);
		
		JLabel lblimg = new JLabel("");
		lblimg.setBounds(1, -80, 500, 500);
		panel.add(lblimg);
		lblimg.setOpaque(false);
		
		ImageIcon img = new ImageIcon("./imagine/doctorilac.jpg");
		lblimg.setIcon(img);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
	}

	public void Save() {
		File file = new File("wishTest.txt");
		
		String Name = tfname.getText();
		String Surname = tfsurname.getText();
		String TC = tfTC.getText();
		String Wishlist = tfwishlist.getText();
		
			tfTC.setText("");
			tfname.setText("");
			tfsurname.setText("");
			tfwishlist.setText("");
			
			
			Patient patient = new Patient.Builder(TC, Name, Surname).TC(TC).Name(Name).Surname(Surname).Wishlist(Wishlist).build();
			
			
		
		if(patient.getTC().equals("")) {
			JOptionPane.showMessageDialog(null, "!!You must write TC!!");
			return;
		}
		else if(patient.getName().equals("")) {
			JOptionPane.showMessageDialog(null, "!!You must write name!!");
			return;
		}
		else if(patient.getSurname().equals("")) {
			JOptionPane.showMessageDialog(null, "!!You must write surname");
			return;
		}
		else if(patient.getWishlist().equals("")) {
			JOptionPane.showMessageDialog(null, "You must write Wish List");
			return;
		}
		JOptionPane.showMessageDialog(null, "Wish List succesfully registered");
		
		try(BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))){  
            writer.write(patient.getTC()+"\n" +patient.getName()+"\n" +patient.getSurname() +"\n"+ patient.getWishlist()  + "\n \n");     
        }
        catch(IOException e1) {
            JOptionPane.showMessageDialog(null, "There was an error opening the file");
        }
		
	}
}