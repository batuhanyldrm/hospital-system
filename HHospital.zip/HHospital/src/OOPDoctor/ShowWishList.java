package OOPDoctor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ShowWishList extends JFrame{
	private JPanel panel;
	private String TC;
	
	public ShowWishList(String TC) {
		setTitle("Show Wish List");
		setSize(500,400);
		
		this.TC = TC;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		JLabel lblswishlist = new JLabel("Show Wish List");
		lblswishlist.setFont(new Font("Dialog", Font.BOLD, 20));
		lblswishlist.setBounds(190, 15, 400, 25);
		panel.add(lblswishlist);
		
		JList wishlist = new JList();
		wishlist.setBounds(135, 60, 250, 50);
		panel.add(wishlist);
		
		
		if(TCIsExist(TC)) {
			ArrayList<String> patientlist = new ArrayList<String>();
			DefaultListModel<String> DLM = new DefaultListModel<String>();
			try {
				Scanner scanner = new Scanner(new BufferedReader(new FileReader("hasta.txt")));
				
				while(scanner.hasNextLine()) {
					String Patient_Info = scanner.nextLine();
					if(Patient_Info.contains(TC)) {
						DLM.addElement(Patient_Info);
						continue;
					}
					wishlist.setModel(DLM);
				}
				scanner.close();
			} catch (Exception e2) {
				JOptionPane.showMessageDialog(null,"Firstly, you should add patient !");
			}
			
		}
		else {
			
		}
		JButton btnback = new JButton("Back");
		btnback.setBounds(220, 120, 65, 25);
		panel.add(btnback);
		
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage mainpage = new MainPage();
				
				setVisible(false);
				mainpage.setVisible(true);
			}
		});
		add(panel);
		
		JLabel lblimg = new JLabel("");
		lblimg.setBounds(1, -80, 500, 500);
		panel.add(lblimg);
		lblimg.setOpaque(false);
		
		ImageIcon img = new ImageIcon("./imagine/doctorilac.jpg");
		lblimg.setIcon(img);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
	}
	public boolean TCIsExist(String TC) {
		if(!TC.equals("")) {
			
			try {
				File tempFile = new File("hasta.txt");
				Scanner tempScanner = new Scanner(new BufferedReader(new FileReader(tempFile)));
				
				while(tempScanner.hasNextLine()) {
					
					if(tempScanner.nextLine().contains(TC)) {
						tempScanner.close();
						return true;
					}
				}
				tempScanner.close();
				return false;
			}
			catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Patient file not found !");
				return false;
			}
		}
		else {
			return false;
		}
	}
}

