package OOPDoctor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MainPage extends JFrame {
	private JPanel panel;
	protected String name, surname;

	public void setName(String name, String surname){
		this.name = name;
		this.surname = surname;
	}

	public MainPage() {
		setTitle("Main Page");
		setSize(500,400);
		
		setLocationRelativeTo(null);
		panel = new JPanel();
		panel.setLayout(null);
		
		JLabel lblmpage = new JLabel("Main Page");
		lblmpage.setFont(new Font("Dialog", Font.BOLD, 20));
		lblmpage.setBounds(193, 15, 150, 30);
		panel.add(lblmpage);
		
		JButton btnallshow = new JButton("All Patient Show");
		btnallshow.setBounds(30, 60, 140, 25);
		add(btnallshow);
		btnallshow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ReadPatient rp = new ReadPatient();
				rp.ReadAllPatients();
				// TODO Auto-generated method stub
				//AllPatientShowPage allpatientshowpage = new AllPatientShowPage();
				//setVisible(false);
				//allpatientshowpage.setVisible(true);
			}
		});
		
		JButton btnshowwishlist = new JButton("Show Wish List");
		btnshowwishlist.setBounds(30, 100, 140, 25);
		btnshowwishlist.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//String TC = JOptionPane.showInputDialog("Please enter the TC");
				//ShowWishList swl = new ShowWishList(TC);
				ReadWish swl = new ReadWish();
				swl.ReadWish();
				//if(swl.ReadPatients(TC)) {
					//setVisible(false);
					//swl.setVisible(true);
				//}
				//else {
					//JOptionPane.showMessageDialog(null, "This patient not found");
					//return;
				//}
				
			}
		});
		
		JButton btnshowpage = new JButton("Patient Show Page");
		btnshowpage.setBounds(30, 140, 140, 25);
		btnshowpage.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String TC = JOptionPane.showInputDialog("Please enter the TC");
				
				ReadPatient psp = new ReadPatient();
				
				//psp.ReadPatients(TC);
				//PatientShowPage psp = new PatientShowPage(TC);
				
				if(psp.ReadPatients(TC)) {
					
					//psp.setVisible(true);
					//setVisible(false);
				}
				else {
					JOptionPane.showMessageDialog(null, "This patient not found");
					return;
				}
			}
		});
		
		JButton btnwishtest = new JButton("Wish Test");
		btnwishtest.setBounds(30, 180, 140, 25);
		btnwishtest.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				WishTest wt = new WishTest();
				//setVisible(false);
				wt.setVisible(true);
				
			}
		});
		JButton btnsurgeryappointment = new JButton("Show Appointment");
		btnsurgeryappointment.setBounds(30, 220, 140, 25);
		btnsurgeryappointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReadAppointment ra = new ReadAppointment();
				ra.ReadDoctorAppointment(name + " " + surname);
				//SurgeryAppointmentShow sas = new SurgeryAppointmentShow();
				//sas.setVisible(true);
				//setVisible(false);
				
			}
		});
		/*JButton btndoctororder = new JButton("Doctor Order");
		btndoctororder.setBounds(30, 260, 140, 25);
		btndoctororder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DoctorOrder doctororder = new DoctorOrder();
				doctororder.setVisible(true);
				setVisible(false);
				
			}
		});*/
		panel.add(btnallshow);
		panel.add(btnshowpage);
		panel.add(btnshowwishlist);
		panel.add(btnwishtest);
		panel.add(btnsurgeryappointment);
		//panel.add(btndoctororder);
		getContentPane().add(panel);
		
		setVisible(true);
		
		JLabel lblimg = new JLabel("");
		lblimg.setBounds(1, -80, 500, 500);
		panel.add(lblimg);
		lblimg.setOpaque(false);
		
		ImageIcon img = new ImageIcon("./imagine/doctorilac.jpg");
		lblimg.setIcon(img);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
	}

	public static void main(String[] args) throws IOException{
		try {
			MainPage mainpage = new MainPage();
			mainpage.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
