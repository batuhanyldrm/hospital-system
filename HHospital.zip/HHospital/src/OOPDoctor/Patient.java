package OOPDoctor;

public class Patient {
	private String TC;
	private String Name;
	private String Surname;
	private String Wishlist;
	private String Medicine;


	public Patient(Builder builder) {
		this.Name = builder.Name;
		this.Surname = builder.Surname;
		this.TC = builder.TC;
		this.Wishlist = builder.Wishlist;
		this.Medicine = builder.Medicine;
	}
	
	public void setMedicine(String Medicine) {
		this.Medicine = Medicine;
	}
	
	public String getMedicine() {
		return this.Medicine;
	}
	
	public String getWishlist() {
		return this.Wishlist;
	}
	
	public void setWishlist(String Wishlist) {
		this.Wishlist = Wishlist;
	}

	public String getTC() {
		return this.TC;
	}



	public void setTC(String TC) {
		this.TC = TC;
	}



	public String getName() {
		return this.Name;
	}



	public void setName(String Name) {
		this.Name = Name;
	}



	public String getSurname() {
		return this.Surname;
	}



	public void setSurname(String Surname) {
		this.Surname = Surname;
	}
	
	
	@Override
	public String toString() {
		return "Patient [TC=" + TC + ", Name=" + Name + ", Surname=" + Surname + ", Wishlist=" + Wishlist
				+ ", Medicine=" + Medicine + "]";
	}
	
	
	
	
	
	public static class Builder{
		
		private String TC;
		private String Name;
		private String Surname;
		private String Wishlist;
		private String Medicine;
		
		public  Builder(String TC, String Name, String Surname){
			this.TC = TC;
			this.Name = Name;
			this.Surname = Surname;
		}
		
		public Builder TC(String TC) {
			this.TC = TC;
			return this;
		}
		
		public Builder Name(String Name) {
			this.Name = Name;
			return this;
		}
		
		public Builder Surname(String Surname) {
			this.Surname = Surname;
			return this;
		}
		
		public Builder Wishlist(String Wishlist) {
			this.Wishlist = Wishlist;
			return this;
		}
		
		public Builder Medicine(String Medicine) {
			this.Medicine = Medicine;
			return this;
		}
		
		public Patient build() {
			Patient patient = new Patient(this);
			return patient;
		}
		
	}
}
