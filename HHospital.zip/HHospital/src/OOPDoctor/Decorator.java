package OOPDoctor;
public interface Decorator {
	void Save();
}