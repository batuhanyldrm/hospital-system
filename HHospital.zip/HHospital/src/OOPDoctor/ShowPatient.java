package OOPDoctor;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ShowPatient {
	public JFrame f;    
	    public String data[][] = new String[10][6];    
	    String column[] = {"firstname", "lastname","gender","bloodgroup","insurance","birthdate"};
	    ShowPatient(){
	        f=new JFrame();

	        JTable jt=new JTable(data,column);    
	        jt.setBounds(30,40,200,300);          
	        JScrollPane sp=new JScrollPane(jt);    
	        
	        f.add(sp);          
	        f.setSize(600,300);
	        f.setTitle("Patient Show Page");
	 }

}
