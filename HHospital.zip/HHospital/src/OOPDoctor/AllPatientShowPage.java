package OOPDoctor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class AllPatientShowPage extends JFrame{
	
	private JPanel panel;
	
	public AllPatientShowPage() {
		setTitle("All Patient Show Page");
		setSize(500, 400);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		JLabel lblopspage = new JLabel("All Patient Show Page");
		lblopspage.setFont(new Font("Dialog", Font.BOLD, 20));
		lblopspage.setBounds(150, 15, 400, 25);
		panel.add(lblopspage);
		
		JList allpatientjlist = new JList();
		allpatientjlist.setBounds(135, 60, 250, 100);
		panel.add(allpatientjlist);
		
		
		
				try {
					
					File tempFile = new File("patients.txt");
					Scanner tempScanner = new Scanner(new BufferedReader(new FileReader(tempFile)));
					ArrayList<String> showList = new ArrayList<String>();
					DefaultListModel<String> DLM = new DefaultListModel<String>();
					
					while(tempScanner.hasNextLine()) {
						
						showList.add(tempScanner.nextLine());
					}
					tempScanner.close();
					
					for(String patient : showList) {
						DLM.addElement(patient);
					}
					
					allpatientjlist.setModel(DLM);
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null,"please save the patient");
				}
				JButton btnback = new JButton("Back");
				btnback.setBounds(220, 200, 65, 25);
				panel.add(btnback);
				
				btnback.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						MainPage mainpage = new MainPage();
						
						setVisible(false);
						mainpage.setVisible(true);
					}
				});
				add(panel);
		
		JLabel lblimg = new JLabel("");
		lblimg.setBounds(1, -80, 500, 500);
		panel.add(lblimg);
		lblimg.setOpaque(false);
		
		ImageIcon img = new ImageIcon("./imagine/doctorilac.jpg");
		lblimg.setIcon(img);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
	}

}
