package OOPDoctor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class SurgeryAppointmentShow extends JFrame{
	private JPanel panel;
	public SurgeryAppointmentShow() {
		setTitle("Surgery Appointment Show Page");
		setSize(500, 400);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		JLabel lblsaspage = new JLabel("Surgery Appointment Show Page");
		lblsaspage.setFont(new Font("Dialog", Font.BOLD, 20));
		lblsaspage.setBounds(100, 15, 400, 25);
		panel.add(lblsaspage);
		
		
		JList surgeryappointmentlist = new JList();
		surgeryappointmentlist.setBounds(135, 60, 250, 100);
		panel.add(surgeryappointmentlist);
		
		try {
			
			File file = new File("hasta.txt");
			Scanner tempScanner = new Scanner(new BufferedReader(new FileReader(file)));
			ArrayList<String> surgeryappointmentshowList = new ArrayList<String>();
			DefaultListModel<String> DLM = new DefaultListModel<String>();
			
			while(tempScanner.hasNextLine()) {
				
				surgeryappointmentshowList.add(tempScanner.nextLine());
			}
			tempScanner.close();
			
			for(String patient : surgeryappointmentshowList) {
				DLM.addElement(patient);
			}
			
			surgeryappointmentlist.setModel(DLM);
			
		} catch (Exception e2) {
			JOptionPane.showMessageDialog(null,"please save the patient");
		}
		JButton btnback = new JButton("Back");
		btnback.setBounds(220, 180, 65, 25);
		panel.add(btnback);
		
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage mainpage = new MainPage();
				
				setVisible(false);
				mainpage.setVisible(true);
			}
		});
		
		add(panel);
		
		JLabel lblimg = new JLabel("");
		lblimg.setBounds(1, -80, 500, 500);
		panel.add(lblimg);
		lblimg.setOpaque(false);
		
		ImageIcon img = new ImageIcon("./imagine/doctorilac.jpg");
		lblimg.setIcon(img);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
	}
}
