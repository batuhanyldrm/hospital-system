package OOPDoctor;

import java.util.*;
import java.io.*;

public class ReadWish {
	private String TC,name,surname,Wishtest;
	public void ReadWish(){
		ShowWish t = new ShowWish();
        try{
            File file = new File("wishTest.txt");
            Scanner scan = new Scanner(file);
            int i = 0;

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                name = scan.nextLine().trim();
                surname = scan.nextLine().trim();
                Wishtest = scan.nextLine().trim();
                scan.nextLine();

                
                    t.data[i][0] = TC;
                    t.data[i][1] = name;
                    t.data[i][2] = surname;
                    t.data[i][3] = Wishtest;
                    
                    i++;
                
                System.out.println(TC);
                System.out.println(name);
                System.out.println(surname);
                System.out.println(Wishtest + "\n");
                System.out.println("Burada");
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+2");
        }
        
    }

}