package OOPDoctor;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DoctorOrder extends JFrame{
	protected static final String Wishlist = null;
	private JPanel panel;
	private JTextField tfTC;
	private JTextField tfname;
	private JTextField tfsurname;
	private JTextField tfmedicine;
	
	public DoctorOrder() {
		setTitle("Doctor Order");
		setSize(500,400);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		
		JLabel lbldorder = new JLabel("Doctor Order");
		lbldorder.setFont(new Font("Dialog", Font.BOLD, 20));
		lbldorder.setBounds(200, 15, 150, 20);
		panel.add(lbldorder);
		
		tfTC = new JTextField(11);
		tfTC.setBounds(250, 60, 150, 20);
		JLabel lbltc = new JLabel("TC :");
		lbltc.setFont(new Font("Dialog", Font.BOLD, 15));
		lbltc.setBounds(125, 50, 40, 40);
		panel.add(lbltc);
		panel.add(tfTC);
		
		tfname = new JTextField(20);
		tfname.setBounds(250, 100, 150, 20);
		JLabel lblname = new JLabel("Name :");
		lblname.setFont(new Font("Dialog", Font.BOLD, 15));
		lblname.setBounds(125, 100, 100, 20);
		panel.add(lblname);
		panel.add(tfname);
		
		tfsurname = new JTextField(20);
		tfsurname.setBounds(250, 140, 150, 20);
		JLabel lblsurname = new JLabel("Surname :");
		lblsurname.setFont(new Font("Dialog", Font.BOLD, 15));
		lblsurname.setBounds(125, 140, 160, 20);
		panel.add(lblsurname);
		panel.add(tfsurname);
		
		tfmedicine = new JTextField(50);
		tfmedicine.setBounds(250, 180, 150, 20);
		JLabel lblmedicine = new JLabel("Medicine :");
		lblmedicine.setFont(new Font("Dialog", Font.BOLD, 15));
		lblmedicine.setBounds(125, 180, 160, 20);
		panel.add(lblmedicine);
		panel.add(tfmedicine);
		
		JButton btnsave = new JButton("Save");
		btnsave.setBounds(160, 220, 65, 25);
		btnsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = new File("order.txt");
				String Name = tfname.getText();
				String Surname = tfsurname.getText();
				String TC = tfTC.getText();
				String Medicine = tfmedicine.getText();
				
				
				tfTC.setText("");
				tfname.setText("");
				tfsurname.setText("");
				tfmedicine.setText("");
				
				Patient patient = new Patient.Builder(TC, Name, Surname).TC(TC).Name(Name).Surname(Surname).Medicine(Medicine).build();
				
				
				
				if(patient.getTC().equals("")) {
					JOptionPane.showMessageDialog(null, "!!You must write TC!!");
					return;
				} 
				else if(patient.getName().equals("")) {
					JOptionPane.showMessageDialog(null, "!!You must write name!!");
					return;
				}
				else if(patient.getSurname().equals("")) {
					JOptionPane.showMessageDialog(null, "!!You must write surname");
					return;
				}
				else if(patient.getMedicine().equals("")) {
					JOptionPane.showMessageDialog(null, "You must write Medicine");
					return;
				}
				JOptionPane.showMessageDialog(null, "Doctor Order succesfully registered");
				
				try(BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))){  
		            writer.write(patient.getTC()+"\n" +patient.getName()+"\n" +patient.getSurname() +"\n"+ patient.getMedicine()  + "\n\n");     
		        }
		        catch(IOException e1) {
		        	JOptionPane.showMessageDialog(null, "There was an error opening the file");
		        }
			}
		});
		JButton btnback = new JButton("Back");
		btnback.setBounds(280, 220, 65, 25);
		panel.add(btnback);
		
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage mainpage = new MainPage();
				
				setVisible(false);
				mainpage.setVisible(true);
			}
		});
		
		panel.add(btnsave);
		add(panel);
		
		JLabel lblimg = new JLabel("");
		lblimg.setBounds(1, -80, 500, 500);
		panel.add(lblimg);
		lblimg.setOpaque(false);
		
		ImageIcon img = new ImageIcon("./imagine/doctorilac.jpg");
		lblimg.setIcon(img);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
	}
}
