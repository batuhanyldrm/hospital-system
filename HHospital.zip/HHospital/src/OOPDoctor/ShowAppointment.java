package OOPDoctor;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ShowAppointment {
	 public JFrame f;    
	    public String data[][] = new String[10][4];    
	    String column[] = {"Doctor", "Hour", "Day", "Month" };
	    ShowAppointment(){
	        f=new JFrame();    

	        JTable jt=new JTable(data,column);    
	        jt.setBounds(30,40,200,300);          
	        JScrollPane sp=new JScrollPane(jt);    
	        
	        f.add(sp);          
	        f.setSize(600,300);    
	        f.setVisible(true);
	        f.setTitle("Appointment Show Page");
	 }

}
