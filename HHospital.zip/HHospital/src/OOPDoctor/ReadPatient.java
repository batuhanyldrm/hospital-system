package OOPDoctor;

import java.util.*;
import java.io.*;

public class ReadPatient {
	private String TC,firstname,lastname,gender,bloodgroup,insurance,birthdate;
	private int check = 0;
	public void ReadAllPatients(){
		ShowPatient t = new ShowPatient();
        try{
            File file = new File("patients.txt");
            Scanner scan = new Scanner(file);
            int i = 0;

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                firstname = scan.nextLine().trim();
                lastname = scan.nextLine().trim();
                gender = scan.nextLine().trim();
                bloodgroup = scan.nextLine().trim();
                insurance = scan.nextLine().trim();
                birthdate = scan.nextLine().trim();
                scan.nextLine();

                
                    t.data[i][0] = firstname;
                    t.data[i][1] = lastname;
                    t.data[i][2] = gender;
                    t.data[i][3] = bloodgroup;
                    t.data[i][4] = insurance;
                    t.data[i][5] = birthdate;
                    
                    i++;
                
                
            }
            scan.close();
            t.f.setVisible(true);

        }catch(Exception e){
            System.out.println(e.getMessage() + "+2");
        }
        
    }
	public boolean ReadPatients(String PTC){
		ShowPatient t = new ShowPatient();
        try{
            File file = new File("patients.txt");
            Scanner scan = new Scanner(file);
            int i = 0;
            

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                firstname = scan.nextLine().trim();
                lastname = scan.nextLine().trim();
                gender = scan.nextLine().trim();
                bloodgroup = scan.nextLine().trim();
                insurance = scan.nextLine().trim();
                birthdate = scan.nextLine().trim();
                scan.nextLine();

                if(TC.equals(PTC)) {
                    t.data[i][0] = firstname;
                    t.data[i][1] = lastname;
                    t.data[i][2] = gender;
                    t.data[i][3] = bloodgroup;
                    t.data[i][4] = insurance;
                    t.data[i][5] = birthdate;
                    
                    i++;
                    check ++;
                    t.f.setVisible(true);
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+2");
        }
        if(check == 0) {
        	return false;
        }else {
        	return true;
        }
        
    }

}

