package Secretary;

public class ProxyPatientSeparator {

    public void Check(String TC){

        InterfaceProxy Ip = new ProxyCheckPatient(TC);

        Ip.PatientCheck();
    }
}
