package Secretary;

public class NotInRoomState extends StateAbstract{

    NotInRoomState(Room room) {
        super(room);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String Hospitalization(String PatientTC, String RoomNo) {
        SaveRoom sr;
        ReadRoom rr = new ReadRoom();

        rr.ReadroomNo(RoomNo);
        if(RoomNo.equals(rr.RoomNo)){
            return "Room is full.";
        }else{
            sr = new SaveRoom(PatientTC, RoomNo);
            return "Patient Hospitalizated.";
        }
        
    }

    @Override
    public String Discharge(String PatientTC) {

        return "Patient is not in a room.";
    }

}
