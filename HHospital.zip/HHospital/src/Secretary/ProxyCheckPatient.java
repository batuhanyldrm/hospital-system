package Secretary;

public class ProxyCheckPatient implements InterfaceProxy{

    GuiPatient gp;
    ReadPatient rp = new ReadPatient();

    private String PatientTC;

    private RealCheckPatient RShow;

    public ProxyCheckPatient(String PatientTC){
        this.PatientTC = PatientTC;
    }

    GuiSavePatient gui = new GuiSavePatient();

    @Override
    public void PatientCheck() {
        try{
            rp.readPatient(PatientTC);

            if(rp.TC.equals(PatientTC)){
                System.out.println("Patient Does Exist");  
                RShow = new RealCheckPatient(PatientTC); 
                RShow.PatientCheck();
            }else{
                System.out.println("Patient does not exist");
                gui.tTC.setText(PatientTC);
                gui.setVisible(true);
            }

        }catch(Exception e){
            System.out.println(e.getMessage() + "+");
        }
        
    }
}
