package Secretary;

import java.io.File;
import java.util.Scanner;

public class ReadPatient {
    public String TC;
    public String Fname;
    public String Lname;
    public String Gender;
    public String BloodGroup;
    public String Insurance;
    public String BDate;
    
    public void readPatient(String PatientTC){
        try{
            File file = new File("Patients.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                Fname = scan.nextLine().trim();
                Lname = scan.nextLine().trim();
                Gender = scan.nextLine().trim();
                BloodGroup = scan.nextLine().trim();
                Insurance = scan.nextLine().trim();
                BDate = scan.nextLine().trim();            scan.nextLine();

                if(TC.equals(PatientTC)){
                    break;
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }
}

