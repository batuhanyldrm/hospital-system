package Secretary;

public interface InterfaceProxy {
    
    public void PatientCheck();
}
