package Secretary;

public abstract class StateAbstract {
    Room room; 

    StateAbstract(Room room){
        this.room = room;
    }

    public abstract String Hospitalization(String PatientTC, String RoomNo);
    public abstract String Discharge(String PatientTC);
}
