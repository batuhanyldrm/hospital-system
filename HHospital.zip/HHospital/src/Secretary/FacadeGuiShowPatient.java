package Secretary;

import javax.swing.*;
import java.awt.*; 
import java.awt.event.*;

public class FacadeGuiShowPatient extends JFrame{

    GuiPatient Gp;
    Room r;
    GuiRoom g;
    ReadDoctor rd;
    ReadAppointment ra;

    public JButton Nap;
    public JButton Sap;
    public JLabel title;

    private Container c;

    public FacadeGuiShowPatient(String PatientTC){
        setTitle("Patient");
        setBounds(200, 90, 1120, 660); 
		setDefaultCloseOperation(DISPOSE_ON_CLOSE); 
        setResizable(false); 

        Gp = new GuiPatient(PatientTC);
        r = new Room(PatientTC);
        g = new GuiRoom(r);
        g.PatientTC = PatientTC;
        
        c = getContentPane(); 
        c.setLayout(null);

        c.add(Gp.title);
        c.add(Gp.Tc);
        c.add(Gp.fname);
        c.add(Gp.lname);
        c.add(Gp.gender);
        c.add(Gp.Bloodgroup);
        c.add(Gp.insurance);
        c.add(Gp.bdate);
        
        c.add(g.title);
        c.add(g.Lroom);
        c.add(g.Troom);
        c.add(g.D);
        c.add(g.H);
        c.add(g.E);

        title = new JLabel("Appointment"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
        title.setLocation(780, 40);
        c.add(title);
        
        Nap = new JButton("Create New Appointment");
        Nap.setFont(new Font("Arial", Font.PLAIN, 15)); 
		Nap.setSize(230, 50); 
        Nap.setLocation(760, 230); 
        Nap.addActionListener(e->{
            rd = new ReadDoctor();
            rd.readDoctorP(PatientTC);
        });
        c.add(Nap);

        Sap = new JButton("Show Patient Appointments");
        Sap.setFont(new Font("Arial", Font.PLAIN, 15)); 
		Sap.setSize(230, 50); 
        Sap.setLocation(760, 150); 
        Sap.addActionListener(e->{
            ra = new ReadAppointment();
            ra.ReadPatientAppointment(PatientTC);
        });
        c.add(Sap);

        setVisible(true);

    }

}
