package Secretary;

public class RealCheckPatient implements InterfaceProxy{
    
    FacadeGuiShowPatient SPatient;
    GuiPatient gp;

    private String PatientTC;

    public RealCheckPatient (String PatientTC){
        this.PatientTC = PatientTC;
    }

    @Override
    public void PatientCheck() {
        SPatient = new FacadeGuiShowPatient(PatientTC);

    }
}
