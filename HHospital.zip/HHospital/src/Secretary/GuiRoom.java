package Secretary;

import javax.swing.*;
import java.awt.*;

public class GuiRoom extends JFrame implements InterfaceFacade{
    private Room room;
    
    public Container c;
    public JLabel title;
    public JLabel Lroom;
    public JTextField Troom;
    public JButton D;
    public JButton H;
    public JLabel E;

    public String PatientTC;
    public String RoomNo;

    public GuiRoom(Room room) {
        this.room = room;

        c = getContentPane(); 
        c.setLayout(null);

        title = new JLabel("Room Operations"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
		title.setLocation(420, 360); 

        Lroom = new JLabel("Room No :"); 
		Lroom.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Lroom.setSize(100, 20); 
        Lroom.setLocation(430, 410); 
        
        Troom = new JTextField(); 
		Troom.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Troom.setSize(100, 20); 
        Troom.setLocation(550, 410); 
        
        D = new JButton("Discharge Patient");
        D.setFont(new Font("Arial", Font.PLAIN, 20)); 
		D.setSize(200, 50); 
        D.setLocation(550, 460); 
        D.addActionListener(e->{
            E.setText(room.getState().Discharge(PatientTC));
            room.state = new NotInRoomState(room);
        });

        H = new JButton("Hospitalization");
        H.setFont(new Font("Arial", Font.PLAIN, 20)); 
		H.setSize(200, 50); 
        H.setLocation(350, 460);
        H.addActionListener(e->{
            String RoomNo = Troom.getText();
            E.setText(room.getState().Hospitalization(PatientTC, RoomNo));
            room.state = new InRoomState(room);
        }); 

        E = new JLabel();
        E.setFont(new Font("Arial", Font.PLAIN, 25)); 
		E.setSize(300, 30); 
		E.setLocation(420, 550); 
        
    }
}