package Secretary;

import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*;

public class GuiMainPage extends JFrame{
	private Container c; 

    private JLabel title;
    private JButton cp; 
    private JButton sr; 
    private JButton sa; 

    GuiCheckPatient gcp;
    GuiShowDoctorApp gs;

	public GuiMainPage() 
	{ 
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setTitle("Secretary Main Page"); 
		setBounds(300, 90, 835, 440); 
		setDefaultCloseOperation(EXIT_ON_CLOSE); 
		setResizable(false); 

		c = getContentPane(); 
		c.setLayout(null); 

		title = new JLabel("Secretary Main Page"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
		title.setLocation(250, 30); 
        c.add(title); 
        

		cp = new JButton("Patient Check"); 
		cp.setFont(new Font("Arial", Font.PLAIN, 15)); 
		cp.setSize(220, 70); 
        cp.setLocation(50, 180); 
        cp.addActionListener(e->{
            gcp = new GuiCheckPatient();
            gcp.setVisible(true);
        });
        c.add(cp); 
        
        sr = new JButton("Show Rooms"); 
		sr.setFont(new Font("Arial", Font.PLAIN, 15)); 
		sr.setSize(220, 70); 
        sr.setLocation(300, 180); 
        sr.addActionListener(e->{
            ReadRoom r = new ReadRoom();
            r.ReadroomPatientS();
        });
        c.add(sr); 
        
        sa = new JButton("Show Doctor Appointments"); 
		sa.setFont(new Font("Arial", Font.PLAIN, 15)); 
		sa.setSize(220, 70); 
        sa.setLocation(550, 180); 
        sa.addActionListener(e->{
            ReadDoctor r = new ReadDoctor();
            r.readDoctorD();
        });
		c.add(sa);  
        
        setVisible(true);
	}

    public static void main(String[] args){
        new GuiMainPage();
    }

}