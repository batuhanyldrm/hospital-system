package Secretary;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class SavePatient {
    public SavePatient(String TC, String Fname, String Lname, String Gender, String BloadGroup, String Insurance, String day, String month, String year){
        try{
            File file = new File("Patients.txt");
            BufferedWriter BF = new BufferedWriter(new FileWriter(file, true));

            BF.write(TC + "\n");
            BF.write(Fname + "\n");
            BF.write(Lname + "\n");
            BF.write(Gender + "\n");
            BF.write(BloadGroup + "\n");
            BF.write(Insurance + "\n");
            BF.write(day + "-" + month + "-" + year + "\n\n");

            BF.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}
