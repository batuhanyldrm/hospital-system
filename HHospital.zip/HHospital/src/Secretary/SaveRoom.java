package Secretary;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class SaveRoom {
    public SaveRoom(String TC, String RoomNo){
        try{
            File file = new File("Rooms.txt");
            BufferedWriter BF = new BufferedWriter(new FileWriter(file, true));

            BF.write(TC + "\n");
            BF.write(RoomNo + "\n\n");

            BF.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}