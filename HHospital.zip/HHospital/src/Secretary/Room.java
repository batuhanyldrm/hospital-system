package Secretary;

public class Room implements InterfaceFacade{
    public StateAbstract state;
    
    ReadRoom rr = new ReadRoom();

    public Room(String PatientTC){
        this.state = new NotInRoomState(this);

        rr.ReadroomPatient(PatientTC);
        if(PatientTC.equals(rr.TC)){
            this.state = new InRoomState(this);
        }else{
            this.state = new NotInRoomState(this);
        }
    }

    public StateAbstract getState() {
        return state;
    }

}
