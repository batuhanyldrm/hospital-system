package Secretary;

import javax.swing.*;
import java.awt.*; 

public class GuiPatient extends JFrame implements InterfaceFacade{
    
    ReadPatient rp = new ReadPatient();

    public Container c;
    public JLabel title;
    public JPanel Panel;
    public JLabel Tc;
    public JLabel fname;
    public JLabel lname;
    public JLabel gender;
    public JLabel Bloodgroup;
    public JLabel insurance;
    public JLabel bdate;

    public GuiPatient(String PatientTC){
        c = getContentPane(); 
        c.setLayout(null);

        System.out.println(PatientTC);
        rp.readPatient(PatientTC);

        title = new JLabel("Patient Infos"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
		title.setLocation(130, 40);
        
        Tc = new JLabel("TC : " + rp.TC); 
		Tc.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Tc.setSize(200, 20); 
        Tc.setLocation(100, 100); 
        c.add(Tc);
        
        fname = new JLabel("Name : " + rp.Fname); 
		fname.setFont(new Font("Arial", Font.PLAIN, 20)); 
		fname.setSize(200, 20); 
		fname.setLocation(100, 125); 
        
        lname = new JLabel("Surname : " + rp.Lname); 
		lname.setFont(new Font("Arial", Font.PLAIN, 20)); 
		lname.setSize(200, 20); 
		lname.setLocation(100, 150); 
        
        gender = new JLabel("Gender : " + rp.Gender); 
		gender.setFont(new Font("Arial", Font.PLAIN, 20)); 
		gender.setSize(200, 20); 
		gender.setLocation(100, 175); 
        c.add(gender);
        
        Bloodgroup = new JLabel("Blood Group : " + rp.BloodGroup); 
		Bloodgroup.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Bloodgroup.setSize(250, 20); 
		Bloodgroup.setLocation(100, 200); 
        c.add(Bloodgroup);
        
        insurance = new JLabel("Insurance : " + rp.Insurance); 
		insurance.setFont(new Font("Arial", Font.PLAIN, 20)); 
		insurance.setSize(300, 20); 
		insurance.setLocation(100, 225); 
		c.add(insurance);

        bdate = new JLabel("Birth Date : " + rp.BDate); 
		bdate.setFont(new Font("Arial", Font.PLAIN, 20)); 
		bdate.setSize(200, 20); 
		bdate.setLocation(100, 250); 
        c.add(bdate);

    }

}
