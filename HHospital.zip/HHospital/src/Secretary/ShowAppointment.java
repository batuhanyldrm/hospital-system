package Secretary;

import javax.swing.*;    
public class ShowAppointment {    
    JFrame f;    
    public String data[][] = new String[10][4];    
    String column[] = {"doctor", "hour", "day", "month" };
    ShowAppointment(){    
        f=new JFrame();    
        f.setTitle("Appointments");
        f.setBounds(400,120,200,300);

        JTable jt=new JTable(data,column);    
        jt.setBounds(30,40,200,300);          
        JScrollPane sp=new JScrollPane(jt);    
        
        f.add(sp);          
        f.setSize(600,400);    
        f.setVisible(true);    
    }     
}  