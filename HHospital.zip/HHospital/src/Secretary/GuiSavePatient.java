package Secretary;

import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*; 

public class GuiSavePatient extends JFrame implements ActionListener{

	private Container c; 
    private JLabel title; 
    private JLabel TC;
    public JTextField tTC;
	private JLabel Fname; 
    private JTextField tFname; 
    private JLabel Lname; 
	private JTextField tLname; 
	private JLabel mno; 
	private JTextField tmno; 
	private JLabel gender; 
	private JRadioButton male; 
	private JRadioButton female; 
	private ButtonGroup gengp; 
	private JLabel dob; 
	private JComboBox date; 
	private JComboBox month; 
	private JComboBox year; 
	private JCheckBox term; 
	private JLabel BloodGroup;
	private JComboBox BloodGroupA;
	private JComboBox BloodGroupRh;
	private JLabel Insurance;
	private JComboBox SInsurance;
	private JButton sub; 
	private JLabel res; 


	private String dates[] 
		= { "1", "2", "3", "4", "5", 
			"6", "7", "8", "9", "10", 
			"11", "12", "13", "14", "15", 
			"16", "17", "18", "19", "20", 
			"21", "22", "23", "24", "25", 
			"26", "27", "28", "29", "30", 
			"31" }; 
	private String months[] 
		= { "1", "2", "3", "4", 
			"5", "6", "7", "8", 
			"9", "10", "11", "12" }; 
	private String years[] 
        = { "1923" , "1924" , "1925" , "1926" , "1927" , "1928" , "1929" , "1930" , "1931" , "1932" , "1933" , "1934" , "1935" , "1936" , "1937" , "1938" , "1939" , "1940" , "1941" , "1942" , "1943" , "1944"
		, "1945" , "1946" , "1947" , "1948" , "1949" , "1950" , "1951" , "1952" , "1953" , "1954" , "1955" , "1956" , "1957" , "1958" , "1959" , "1960" , "1961" , "1962" , "1963" , "1964" , "1965" , "1966" , "1967" , "1968" , "1969"
		, "1970" , "1971" , "1972" , "1973" , "1974" , "1975" , "1976" , "1977" , "1978" , "1979" , "1980" , "1981" , "1982" , "1983" , "1984" , "1985" , "1986" , "1987" , "1988" , "1989" , "1990" , "1991" , "1992"
		, "1993" , "1994" , "1995" , "1996" , "1997" , "1998" , "1999" , "2000" , "2001" , "2002" , "2003" , "2004" , "2005" , "2006" , "2007" , "2008" , "2009" , "2010" , "2011" , "2012" , "2013" , "2014" , "2015"
		, "2016" , "2017" , "2018" , "2019" , "2020" , "2021" }; 

	private String Bloodgroup[]
		= {
			"A", "B", "AB", "0"
		};
	private String BloodgroupRh[]
		= {
			"Rh+", "Rh-"
		};

	private String insurance[]
		= {
			"Special Insurance",
			"State Insurance"
		};


	public GuiSavePatient() 
	{ 
		setTitle("Registration Form"); 
		setBounds(430, 90, 600, 620); 
		setDefaultCloseOperation(DISPOSE_ON_CLOSE); 
		setResizable(false); 

		c = getContentPane(); 
		c.setLayout(null); 

		title = new JLabel("Registration Form"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
		title.setLocation(165, 30); 
        c.add(title); 
        
        TC = new JLabel("T.C");
        TC.setFont(new Font("Arial", Font.PLAIN, 20));
        TC.setSize(100,20);
        TC.setLocation(100,100);
        c.add(TC);

        tTC = new JTextField();
        tTC.setFont(new Font("Arial", Font.PLAIN, 15)); 
		tTC.setSize(190, 20); 
		tTC.setLocation(200, 100); 
		c.add(tTC); 

		Fname = new JLabel("Name"); 
		Fname.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Fname.setSize(100, 20); 
		Fname.setLocation(100, 150); 
		c.add(Fname); 

		tFname = new JTextField(); 
		tFname.setFont(new Font("Arial", Font.PLAIN, 15)); 
		tFname.setSize(190, 20); 
		tFname.setLocation(200, 150); 
        c.add(tFname); 
        
        Lname = new JLabel("Surname"); 
		Lname.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Lname.setSize(100, 20); 
		Lname.setLocation(100, 200); 
		c.add(Lname); 

		tLname = new JTextField(); 
		tLname.setFont(new Font("Arial", Font.PLAIN, 15)); 
		tLname.setSize(190, 20); 
		tLname.setLocation(200, 200); 
		c.add(tLname); 


		mno = new JLabel("Mobile"); 
		mno.setFont(new Font("Arial", Font.PLAIN, 20)); 
		mno.setSize(100, 20); 
		mno.setLocation(100, 2000); 
		c.add(mno); 

		tmno = new JTextField(); 
		tmno.setFont(new Font("Arial", Font.PLAIN, 15)); 
		tmno.setSize(150, 20); 
		tmno.setLocation(200, 2000); 
		c.add(tmno); 

		gender = new JLabel("Gender"); 
		gender.setFont(new Font("Arial", Font.PLAIN, 20)); 
		gender.setSize(100, 20); 
		gender.setLocation(100, 250); 
		c.add(gender); 

		male = new JRadioButton("Male"); 
		male.setFont(new Font("Arial", Font.PLAIN, 15)); 
		male.setSelected(true); 
		male.setSize(75, 20); 
		male.setLocation(200, 250); 
		c.add(male); 

		female = new JRadioButton("Female"); 
		female.setFont(new Font("Arial", Font.PLAIN, 15)); 
		female.setSelected(false); 
		female.setSize(80, 20); 
		female.setLocation(275, 250); 
		c.add(female); 

		gengp = new ButtonGroup(); 
		gengp.add(male); 
		gengp.add(female); 

		dob = new JLabel("DOB"); 
		dob.setFont(new Font("Arial", Font.PLAIN, 20)); 
		dob.setSize(100, 20); 
		dob.setLocation(100, 300); 
		c.add(dob); 

		date = new JComboBox(dates); 
		date.setFont(new Font("Arial", Font.PLAIN, 15)); 
		date.setSize(50, 20); 
		date.setLocation(200, 300); 
		c.add(date); 

		month = new JComboBox(months); 
		month.setFont(new Font("Arial", Font.PLAIN, 15)); 
		month.setSize(60, 20); 
		month.setLocation(250, 300); 
		c.add(month); 

		year = new JComboBox(years); 
		year.setFont(new Font("Arial", Font.PLAIN, 15)); 
		year.setSize(60, 20); 
		year.setLocation(320, 300); 
		c.add(year); 

		BloodGroup = new JLabel("Blood Group");
		BloodGroup.setFont(new Font("Arial", Font.PLAIN, 20)); 
		BloodGroup.setSize(150, 20); 
		BloodGroup.setLocation(100, 350); 
		c.add(BloodGroup);

		BloodGroupA = new JComboBox(Bloodgroup);
		BloodGroupA.setFont(new Font("Arial", Font.PLAIN, 15));
		BloodGroupA.setSize(60, 20); 
		BloodGroupA.setLocation(230, 350); 
		c.add(BloodGroupA);

		BloodGroupRh = new JComboBox(BloodgroupRh);
		BloodGroupRh.setFont(new Font("Arial", Font.PLAIN, 15));
		BloodGroupRh.setSize(60, 20); 
		BloodGroupRh.setLocation(300, 350); 
		c.add(BloodGroupRh);

		Insurance = new JLabel("Insurance");
		Insurance.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Insurance.setSize(100, 20); 
		Insurance.setLocation(100, 400); 
		c.add(Insurance);

		SInsurance = new JComboBox(insurance);
		SInsurance.setFont(new Font("Arial", Font.PLAIN, 15));
		SInsurance.setSize(200, 20); 
		SInsurance.setLocation(200, 400); 
		c.add(SInsurance);
		
		term = new JCheckBox("Accept Terms And Conditions."); 
		term.setFont(new Font("Arial", Font.PLAIN, 15)); 
		term.setSize(250, 20); 
		term.setLocation(150, 450); 
		c.add(term); 

		sub = new JButton("Submit"); 
		sub.setFont(new Font("Arial", Font.PLAIN, 15)); 
		sub.setSize(100, 20); 
		sub.setLocation(250, 500); 
		sub.addActionListener(this); 
		c.add(sub); 

		res = new JLabel(""); 
		res.setFont(new Font("Arial", Font.PLAIN, 20)); 
		res.setSize(500, 25); 
		res.setLocation(100, 500); 
		c.add(res); 
	}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == sub) {
			if (term.isSelected()) { 
				String gender;
				if (male.isSelected()) 
					gender = "Male";
				else
					gender = "Female";


				new SavePatient(tTC.getText(), tFname.getText(), tLname.getText(), gender, (String)BloodGroupA.getSelectedItem() + "\b" + (String)BloodGroupRh.getSelectedItem(), (String)SInsurance.getSelectedItem(), (String)date.getSelectedItem(), (String)month.getSelectedItem(), (String)year.getSelectedItem());
                setVisible(false);
			}
			else
				JOptionPane.showMessageDialog(null, "You have to fill all the areas.");
        }        
    }

}