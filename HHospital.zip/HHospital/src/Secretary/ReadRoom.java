package Secretary;

import java.io.File;
import java.util.Scanner;

public class ReadRoom {
    public String TC;
    public String RoomNo;
    
    public void ReadroomPatient(String PatientTC){
        try{
            File file = new File("Rooms.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                RoomNo = scan.nextLine().trim();            scan.nextLine();

                if(TC.equals(PatientTC)){
                    break;
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }

    public void ReadroomNo(String Roomno){
        try{
            File file = new File("Rooms.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                RoomNo = scan.nextLine().trim();            scan.nextLine();

                if(RoomNo.equals(Roomno)){
                    break;
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }

    public void ReadroomPatientS(){
        ShowRooms s = new ShowRooms();
        ReadPatient rp = new ReadPatient();
        int i = 0;
        try{
            File file = new File("Rooms.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                RoomNo = scan.nextLine().trim();            scan.nextLine();

                rp.readPatient(TC);

                if(TC.equals(rp.TC)){
                    s.data[i][0] = RoomNo;
                    s.data[i][1] = rp.Fname + " " + rp.Lname;

                    i++;
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }
}