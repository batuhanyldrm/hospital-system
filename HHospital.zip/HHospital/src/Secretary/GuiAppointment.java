package Secretary;

import javax.swing.*;
import java.awt.*;

public class GuiAppointment extends JFrame{

    SaveAppointment sA;

    private Container c;
    private JLabel title;
    private JLabel LTC;
    public JTextField TTC;
    private JLabel Lhour;
    private JLabel Lday;
    private JLabel Lmonth;
    private JLabel Ldoctor;
    private JComboBox hour; 
    private JComboBox day; 
    private JComboBox month; 
    public JComboBox doctor; 
	private JButton sub;
	private JButton close;
	public JLabel s;

    private String Hours[]
        = {
            "08.00", "09.00", "10.00", "11.00", "12.00",
            "13.00", "14.00", "15.00", "16.00", "17.00"
        };
    private String days[] 
		= { "1", "2", "3", "4", "5", 
			"6", "7", "8", "9", "10", 
			"11", "12", "13", "14", "15", 
			"16", "17", "18", "19", "20", 
			"21", "22", "23", "24", "25", 
			"26", "27", "28", "29", "30", 
			"31" }; 
	private String months[] 
		= { "1", "2", "3", "4", 
			"5", "6", "7", "8", 
			"9", "10", "11", "12" }; 



        
    public GuiAppointment(){
		setTitle("Appointment"); 
		setBounds(400, 90, 600, 620); 
		setDefaultCloseOperation(DISPOSE_ON_CLOSE); 
		setResizable(false); 

		c = getContentPane(); 
		c.setLayout(null); 

		title = new JLabel("Appointment Form"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
		title.setLocation(165, 30); 
        c.add(title); 

        LTC = new JLabel("T.C");
        LTC.setFont(new Font("Arial", Font.PLAIN, 20));
        LTC.setSize(100,20);
        LTC.setLocation(100,100);
        c.add(LTC);

        TTC = new JTextField();
        TTC.setFont(new Font("Arial", Font.PLAIN, 15)); 
		TTC.setSize(190, 20); 
		TTC.setLocation(200, 100); 
        c.add(TTC); 
        
        Ldoctor = new JLabel("Doctor"); 
		Ldoctor.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Ldoctor.setSize(100, 20); 
		Ldoctor.setLocation(100, 150); 
        c.add(Ldoctor); 
		
        doctor = new JComboBox(); 
		doctor.setFont(new Font("Arial", Font.PLAIN, 15)); 
		doctor.setSize(200, 20); 
		doctor.setLocation(200, 150); 
        c.add(doctor);

        Lhour = new JLabel("Hour"); 
		Lhour.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Lhour.setSize(100, 20); 
		Lhour.setLocation(100, 200); 
        c.add(Lhour); 

        hour = new JComboBox(Hours); 
		hour.setFont(new Font("Arial", Font.PLAIN, 15)); 
		hour.setSize(100, 20); 
		hour.setLocation(200, 200); 
        c.add(hour);
        
        Lday = new JLabel("Day"); 
		Lday.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Lday.setSize(100, 20); 
		Lday.setLocation(100, 250); 
        c.add(Lday); 

        day = new JComboBox(days); 
		day.setFont(new Font("Arial", Font.PLAIN, 15)); 
		day.setSize(100, 20); 
		day.setLocation(200, 250); 
		c.add(day); 

        Lmonth = new JLabel("Month"); 
		Lmonth.setFont(new Font("Arial", Font.PLAIN, 20)); 
		Lmonth.setSize(100, 20); 
		Lmonth.setLocation(100, 300); 
        c.add(Lmonth); 

		month = new JComboBox(months); 
		month.setFont(new Font("Arial", Font.PLAIN, 15)); 
		month.setSize(100, 20); 
		month.setLocation(200, 300); 
		c.add(month); 

		s = new JLabel(); 
		s.setFont(new Font("Arial", Font.PLAIN, 25)); 
		s.setSize(400, 30); 
		s.setLocation(135, 400); 
        c.add(s); 

		sub = new JButton("Submit"); 
		sub.setFont(new Font("Arial", Font.PLAIN, 15)); 
		sub.setSize(100, 20); 
		sub.setLocation(180, 500); 
		sub.addActionListener(e->{
			sA = new SaveAppointment(TTC.getText(), (String)doctor.getSelectedItem(), (String)hour.getSelectedItem(), (String)day.getSelectedItem(), (String)month.getSelectedItem());
			s.setText(sA.m);
		}); 
		c.add(sub);

		close = new JButton("Close"); 
		close.setFont(new Font("Arial", Font.PLAIN, 15)); 
		close.setSize(100, 20); 
		close.setLocation(320, 500); 
		close.addActionListener(e->{
			setVisible(false);
		}); 
		c.add(close);
		setVisible(true);
		
    }
}
