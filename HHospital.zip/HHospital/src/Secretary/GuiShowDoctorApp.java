package Secretary;

import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*;

public class GuiShowDoctorApp extends JFrame{

	private Container c; 
    private JLabel title; 
    private JLabel D;
    public JComboBox Doctors; 
	private JButton sub; 


	public GuiShowDoctorApp() 
	{ 
		
		setTitle("Choose Doctor"); 
		setBounds(300, 90, 835, 440); 
		setDefaultCloseOperation(DISPOSE_ON_CLOSE); 
		setResizable(false); 

		c = getContentPane(); 
		c.setLayout(null); 

		title = new JLabel("Doctor Choose"); 
		title.setFont(new Font("Arial", Font.PLAIN, 30)); 
		title.setSize(300, 30); 
		title.setLocation(320, 30); 
        c.add(title); 
        
        D = new JLabel("T.C");
        D.setFont(new Font("Arial", Font.PLAIN, 20));
        D.setSize(100,20);
        D.setLocation(280,160);
        c.add(D);

        Doctors = new JComboBox();
        Doctors.setFont(new Font("Arial", Font.PLAIN, 15)); 
		Doctors.setSize(190, 20); 
		Doctors.setLocation(340, 160); 
		c.add(Doctors); 

		sub = new JButton("Submit"); 
		sub.setFont(new Font("Arial", Font.PLAIN, 15)); 
		sub.setSize(180, 50); 
        sub.setLocation(300, 250);  
        sub.addActionListener(e->{
            ReadAppointment r =  new ReadAppointment();
            r.ReadDoctorAppointment((String)Doctors.getSelectedItem());
            setVisible(false);
        });
		c.add(sub); 

        setVisible(true);
	}

}