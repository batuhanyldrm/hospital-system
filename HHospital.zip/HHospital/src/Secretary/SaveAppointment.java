package Secretary;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class SaveAppointment {
    public String m;
    public SaveAppointment(String TC, String doctor, String hour, String day, String month){
        int check = 0;
        try{
            File file = new File("Appointments.txt");
            BufferedWriter BF = new BufferedWriter(new FileWriter(file, true));
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                String TTC = scan.nextLine().trim();
                String Tdoctor = scan.nextLine().trim();
                String Thour = scan.nextLine().trim();
                String Tday = scan.nextLine().trim();
                String Tmonth = scan.nextLine().trim();           scan.nextLine();
                
                if(doctor.equals(Tdoctor) && hour.equals(Thour) && day.equals(Tday) && month.equals(Tmonth)){
                    check++;
                }
            }
            scan.close();

            if(check == 0){
                BF.write(TC + "\n");
                BF.write(doctor + "\n");
                BF.write(hour + "\n");
                BF.write(day + "\n");
                BF.write(month + "\n\n");
                m = "The appointment has been saved";
            }else{
                m = "Could not save appointment";
            }

            BF.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}