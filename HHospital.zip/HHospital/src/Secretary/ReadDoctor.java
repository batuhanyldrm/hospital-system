package Secretary;

import java.io.File;
import java.util.Scanner;

public class ReadDoctor {

    public String Fname;
    public String Lname;
    int i = 0;
    
    public void readDoctorP(String PatientTC){
        GuiAppointment ga = new GuiAppointment();
        try{
            File file = new File("doctorFile.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
               scan.nextLine().trim();
                Fname = scan.nextLine().trim();
                Lname = scan.nextLine().trim();
                scan.nextLine().trim();
                scan.nextLine().trim();
                scan.nextLine().trim();
                scan.nextLine().trim();            
                scan.nextLine().trim();         scan.nextLine();

                ga.doctor.addItem(Fname + " " + Lname);                
                
            }
            scan.close();
            ga.TTC.setText(PatientTC);

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }

    public void readDoctorD(){
        GuiShowDoctorApp gs = new GuiShowDoctorApp();
        try{
            File file = new File("doctorFile.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
               scan.nextLine().trim();
                Fname = scan.nextLine().trim();
                Lname = scan.nextLine().trim();
                scan.nextLine().trim();
                scan.nextLine().trim();
                scan.nextLine().trim();
                scan.nextLine().trim();            
                scan.nextLine().trim();         scan.nextLine();

                gs.Doctors.addItem(Fname + " " + Lname);
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }
}

