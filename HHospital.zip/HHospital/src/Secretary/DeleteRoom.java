package Secretary;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class DeleteRoom {
    public String TC;
    public String RoomNo;
    
    public void DeleteRoom(String PatientTC){
        try{
            File file = new File("Rooms.txt");
            File temp = new File("Temp.txt");
            Scanner scan = new Scanner(file);
            BufferedWriter BF = new BufferedWriter(new FileWriter(temp, true));

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                RoomNo = scan.nextLine().trim();            scan.nextLine();

                if(TC.equals(PatientTC)){
                    continue;
                }else{
                    BF.write(TC + "\n");
                    BF.write(RoomNo + "\n\n");
        
                }
                
            }
            scan.close();
            BF.close();


            file.delete();
            temp.renameTo(file);

        }catch(Exception e){
            System.out.println(e.getMessage() + "+1");
        }
        
    }
}