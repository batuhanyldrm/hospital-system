package Secretary;

import java.io.File;
import java.util.Scanner;

public class ReadAppointment implements InterfaceFacade{
    ShowAppointment t = new ShowAppointment();

    public String TC;
    public String doctor;
    public String hour;
    public String day;
    public String month;

    public String arr[][];

    private int i = 0;


    public void ReadPatientAppointment(String PatientTC){
        try{
            File file = new File("Appointments.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                doctor = scan.nextLine().trim();
                hour = scan.nextLine().trim();
                day = scan.nextLine().trim();
                month = scan.nextLine().trim();           scan.nextLine();

                if(TC.equals(PatientTC)){
                    t.data[i][0] = doctor;
                    t.data[i][1] = hour;
                    t.data[i][2] = day;
                    t.data[i][3] = month;
                    
                    i++;
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+2");
        }
        
    }

    public void ReadDoctorAppointment(String Doctor){
        try{
            File file = new File("Appointments.txt");
            Scanner scan = new Scanner(file);

            while(scan.hasNextLine()){
                TC = scan.nextLine().trim();
                doctor = scan.nextLine().trim();
                hour = scan.nextLine().trim();
                day = scan.nextLine().trim();
                month = scan.nextLine().trim();           scan.nextLine();

                if(doctor.equals(Doctor)){
                    t.data[i][0] = doctor;
                    t.data[i][1] = hour;
                    t.data[i][2] = day;
                    t.data[i][3] = month;
                    
                    i++;
                }
                
            }
            scan.close();

        }catch(Exception e){
            System.out.println(e.getMessage() + "+2");
        }
        
    }
}

