package Secretary;

public class InRoomState extends StateAbstract{

    InRoomState(Room room) {
        super(room);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String Hospitalization(String PatientTC, String RoomNo) {
        return "Patient already in a room";
    }

    @Override
    public String Discharge(String PatientTC) {
        DeleteRoom dr = new DeleteRoom();

        dr.DeleteRoom(PatientTC);

        return "Patient Discharged.";
    }
    
}
