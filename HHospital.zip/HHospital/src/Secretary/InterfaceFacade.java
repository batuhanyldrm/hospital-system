package Secretary;

public interface InterfaceFacade {
    
}
